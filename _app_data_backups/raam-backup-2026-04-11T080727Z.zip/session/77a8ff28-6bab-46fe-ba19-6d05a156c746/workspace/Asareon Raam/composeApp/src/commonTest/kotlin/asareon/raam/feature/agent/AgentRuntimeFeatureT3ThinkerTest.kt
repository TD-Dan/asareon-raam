package asareon.raam.feature.agent

import asareon.raam.core.Action
import asareon.raam.core.generated.ActionRegistry
import asareon.raam.fakes.FakePlatformDependencies
import asareon.raam.feature.filesystem.FileSystemFeature
import asareon.raam.feature.session.SessionFeature
import asareon.raam.test.TestEnvironment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.*
import kotlin.test.*

/**
 * Tier 2/3 Test for AgentCognitivePipeline (The Thinker).
 * Replaces the monolithic T2CoreTest.
 * Verifies the Cognitive Cycle: Ledger -> Context -> Prompt -> Gateway
 */
class AgentRuntimeFeatureT3ThinkerTest {

    private val scope = CoroutineScope(Dispatchers.Unconfined)
    private val platform = FakePlatformDependencies("test")
    private val feature = AgentRuntimeFeature(platform, scope)

    // All IDs must be valid UUIDs — the Store validates UUID format on REGISTER_IDENTITY
    // and the reducer validates with stringIsUUID() on SESSION_MESSAGE_POSTED
    private val agentUUID = "b0000000-0000-0000-0000-000000000001"
    private val sessionUUID = "a0000000-0000-0000-0000-000000000001"

    private val agent = testAgent(agentUUID, "Test", modelProvider = "p", modelName = "m",
        subscribedSessionIds = listOf(sessionUUID),
        resources = mapOf("system_instruction" to "res-sys-instruction-v1")
    )

    @Test
    fun `INITIATE_TURN dispatches REQUEST_LEDGER_CONTENT`() = runTest {
        val harness = TestEnvironment.create()
            .withFeature(feature)
            .withFeature(FileSystemFeature(platform))
            .withFeature(SessionFeature(platform, scope))
            .withInitialState("agent", AgentRuntimeState(agents = mapOf(agent.identityUUID to agent), resources = testBuiltInResources()))
            .build(platform = platform)

        harness.runAndLogOnFailure {
            // Register identities so resolveAgentId and session UUID validation work
            harness.registerAgentIdentity(agent)
            harness.registerSessionIdentity(sessionUUID, "Test Session")

            val action = Action(ActionRegistry.Names.AGENT_INITIATE_TURN, buildJsonObject { put("agentId", agent.identity.uuid) })
            harness.store.dispatch("core", action)

            val request = harness.processedActions.find { it.name == ActionRegistry.Names.SESSION_REQUEST_LEDGER_CONTENT }
            assertNotNull(request)
            // Phase B: correlationId is now compound "agentUUID::sessionUUID" for multi-session accumulation
            val correlationId = request.payload?.get("correlationId")?.jsonPrimitive?.content
            assertNotNull(correlationId)
            assertTrue(correlationId.startsWith(agentUUID),
                "Compound correlationId should start with agent UUID, got: $correlationId")
        }
    }

    @Test
    fun `handleLedgerResponse stages context and triggers full context gathering`() = runTest {
        // This test verifies the full pipeline from ledger response to gateway request.
        // The flow is: LedgerResponse → STAGE_TURN_CONTEXT → evaluateTurnContext
        // → FILESYSTEM_LIST → FileSystemFeature → SET_WORKSPACE_CONTEXT
        // → evaluateFullContext (gate) → executeTurn → GATEWAY_GENERATE_CONTENT

        val harness = TestEnvironment.create()
            .withFeature(feature)
            .withFeature(FileSystemFeature(platform))
            .withInitialState("agent", AgentRuntimeState(agents = mapOf(agent.identityUUID to agent), resources = testBuiltInResources()))
            .build(platform = platform)

        harness.runAndLogOnFailure {
            val response = Action(
                name = ActionRegistry.Names.SESSION_RETURN_LEDGER,
                payload = buildJsonObject {
                    put("correlationId", agent.identity.uuid)
                    put("messages", buildJsonArray {
                        add(buildJsonObject {
                            put("senderId", "user")
                            put("rawContent", "Hello")
                            put("timestamp", 1000L)
                        })
                    })
                },
                targetRecipient = "agent"
            )

            // ACT
            harness.store.dispatch("session", response)

            // ASSERT 1: STAGE_TURN_CONTEXT dispatched
            val stageAction = harness.processedActions.find { it.name == ActionRegistry.Names.AGENT_STAGE_TURN_CONTEXT }
            assertNotNull(stageAction)

            // ASSERT 2: GATEWAY_GENERATE_CONTENT dispatched (proving full context pipeline completed)
            // This proves the loop: PrivateData -> Pipeline -> STAGE_TURN_CONTEXT -> evaluateTurnContext
            // -> FILESYSTEM_LIST -> FileSystemFeature -> SET_WORKSPACE_CONTEXT -> evaluateFullContext -> executeTurn
            val gatewayAction = harness.processedActions.find { it.name == ActionRegistry.Names.GATEWAY_GENERATE_CONTENT }
            assertNotNull(gatewayAction)
        }
    }

    @Test
    fun `sentinel warning does not trigger new turn`() = runTest {
        // Verifies the Sentinel Fix in a full loop context
        val harness = TestEnvironment.create()
            .withFeature(feature)
            .withFeature(FileSystemFeature(platform))
            .withInitialState("agent", AgentRuntimeState(agents = mapOf(agent.identityUUID to agent), resources = testBuiltInResources()))
            .build(platform = platform)

        harness.runAndLogOnFailure {
            val sentinelMsg = Action(ActionRegistry.Names.SESSION_MESSAGE_POSTED, buildJsonObject {
                put("sessionId", sessionUUID)
                put("entry", buildJsonObject {
                    put("id", "msg-1")
                    put("senderId", "system") // <--- Sentinel
                    put("timestamp", 1000L)
                })
            })

            // ACT
            harness.store.dispatch("session", sentinelMsg)

            // ASSERT: Agent status remains IDLE (null/default)
            val state = harness.store.state.value.featureStates["agent"] as AgentRuntimeState
            val status = state.agentStatuses[agent.identityUUID]?.status ?: AgentStatus.IDLE
            assertEquals(AgentStatus.IDLE, status)
        }
    }

    @Test
    fun `startCognitiveCycle should fail gracefully and set ERROR status if agent has no sessions`() = runTest {
        // ARRANGE
        val orphanAgent = testAgent("b0000000-0000-0000-0000-000000000099", "Orphan", modelProvider = "p", modelName = "m", subscribedSessionIds = emptyList(), privateSessionId = null)
        val harness = TestEnvironment.create()
            .withFeature(feature)
            .withFeature(FileSystemFeature(platform))
            .withInitialState("agent", AgentRuntimeState(agents = mapOf(orphanAgent.identityUUID to orphanAgent), resources = testBuiltInResources()))
            .build(platform = platform)

        harness.runAndLogOnFailure {
            // Register agent identity so resolveAgentId works
            harness.registerAgentIdentity(orphanAgent)

            // ACT
            harness.store.dispatch("core", Action(ActionRegistry.Names.AGENT_INITIATE_TURN, buildJsonObject {
                put("agentId", orphanAgent.identity.uuid)
            }))

            // ASSERT
            val state = harness.store.state.value.featureStates["agent"] as AgentRuntimeState
            val status = state.agentStatuses[orphanAgent.identityUUID]

            // Should be ERROR status
            assertEquals(AgentStatus.ERROR, status?.status)
            // Should have descriptive error message
            assertTrue(status?.errorMessage?.contains("no session") == true)
            // Should NOT have dispatched a ledger request
            assertNull(harness.processedActions.find { it.name == ActionRegistry.Names.SESSION_REQUEST_LEDGER_CONTENT })
        }
    }

    @Test
    fun `handleLedgerResponse should handle malformed JSON gracefully`() = runTest {
        // ARRANGE
        val harness = TestEnvironment.create()
            .withFeature(feature)
            .withFeature(FileSystemFeature(platform))
            .withInitialState("agent", AgentRuntimeState(agents = mapOf(agent.identityUUID to agent), resources = testBuiltInResources()))
            .build(platform = platform)

        harness.runAndLogOnFailure {
            // ACT: Send malformed payload in envelope
            harness.store.dispatch("session", Action(
                name = ActionRegistry.Names.SESSION_RETURN_LEDGER,
                payload = buildJsonObject {
                    put("correlationId", agent.identity.uuid)
                    // Missing "messages" array, or other schema violation
                    put("invalid_key", "invalid_value")
                },
                targetRecipient = "agent"
            ))

            // ASSERT
            val state = harness.store.state.value.featureStates["agent"] as AgentRuntimeState
            val status = state.agentStatuses[agent.identityUUID]

            // Should transition to ERROR
            assertEquals(AgentStatus.ERROR, status?.status)
            assertTrue(status?.errorMessage?.contains("Failed to parse ledger") == true)
        }
    }

    @Test
    fun `evaluateFullContext should abort if staged ledger context is missing (State Integrity)`() = runTest {
        // ARRANGE
        // Status has NO stagedTurnContext, simulating a desync or cancellation.
        // But contextGatheringStartedAt and workspace must be set so the gate proceeds.
        val status = AgentStatusInfo(
            status = AgentStatus.PROCESSING,
            stagedTurnContext = null,
            contextGatheringStartedAt = platform.currentTimeMillis(),
            transientWorkspaceListing = JsonArray(emptyList())
        )
        val harness = TestEnvironment.create()
            .withFeature(feature)
            .withFeature(FileSystemFeature(platform))
            .withInitialState("agent", AgentRuntimeState(
                agents = mapOf(agent.identityUUID to agent),
                agentStatuses = mapOf(agent.identityUUID to status),
                resources = testBuiltInResources()
            ))
            .build(platform = platform)

        harness.runAndLogOnFailure {
            // ACT: Trigger a context arrival (e.g. workspace or HKG) without staged ledger
            harness.store.dispatch("knowledgegraph", Action(
                name = ActionRegistry.Names.KNOWLEDGEGRAPH_RETURN_CONTEXT,
                payload = buildJsonObject {
                    put("correlationId", agent.identity.uuid)
                    put("context", buildJsonObject { put("some", "data") })
                },
                targetRecipient = "agent"
            ))

            // ASSERT
            val state = harness.store.state.value.featureStates["agent"] as AgentRuntimeState
            val finalStatus = state.agentStatuses[agent.identityUUID]

            // Should abort and set ERROR
            assertEquals(AgentStatus.ERROR, finalStatus?.status)
            // The pipeline should abort with a context/turn-related error message
            assertNotNull(finalStatus?.errorMessage, "Should have an error message when staged context is missing")

            // Should NOT proceed to Gateway
            assertNull(harness.processedActions.find { it.name == ActionRegistry.Names.GATEWAY_GENERATE_CONTENT })
        }
    }
}