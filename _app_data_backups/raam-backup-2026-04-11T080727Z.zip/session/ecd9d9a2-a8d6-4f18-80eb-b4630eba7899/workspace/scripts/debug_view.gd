extends CanvasLayer

@export var tracked_player : Node
@export var tracked_camera : Node

@onready var player_text = %PlayerText
@onready var camera_text = %CameraText

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if tracked_player:
		player_text.text = "%.2f %.2f" % [tracked_player.position.x, tracked_player.position.y] + "\n"
		player_text.text += "%.2f %.2f" % [tracked_player.velocity.x, tracked_player.velocity.y] + "\n"
		player_text.text += tracked_player.movemode_state.current_state + "\n"
		player_text.text += tracked_player.speed_state.current_state + "\n"
		player_text.text += tracked_player.active_lateral_state.current_state + "\n"
		player_text.text += tracked_player.active_vertical_state.current_state + "\n"
		player_text.text += "rot: %.2f targ: %.2f" % [tracked_player.rotation, tracked_player._rotation_target] + "\n"
	if tracked_camera:
		camera_text.text = "%.2f %.2f" % [tracked_camera.position.x, tracked_camera.position.y] + "\n"

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("Debug"):
		self.visible = not self.visible
