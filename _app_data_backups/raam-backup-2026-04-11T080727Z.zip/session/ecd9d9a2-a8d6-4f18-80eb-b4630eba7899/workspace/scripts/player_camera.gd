extends Camera2D


@export var follow_target : Node2D:
	set(nv):
		# If follow target has specified a anchor node, use that
		_follow_target = nv
		print("setting follow target to %s" % follow_target)
		if follow_target:
			print("finding anchor!")
			var follow_anchor = follow_target.get("follow_anchor")
			if follow_anchor:
				print("found anchor! %s" % follow_anchor.name)
				_follow_target = follow_anchor
	get:
		return _follow_target
var _follow_target : Node2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	if follow_target:
		position = follow_target.get_global_transform().origin
