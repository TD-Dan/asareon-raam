## InteractionSurface — Directional Interaction Zone
## Attach to an Area2D that represents one side of an entity's interaction zone.
class_name InteractionSurface
extends Area2D

## The local direction this surface faces (relative to entity, unrotated).
## Set this to Vector2.UP for top, Vector2.RIGHT for right, etc.
@export var facing: Vector2 = Vector2.UP

## Damage dealt to the opposing surface's entity.
@export var damage_value: int = 0

## Damage absorbed from the opposing surface.
@export var shield_value: int = 0

## Bounce coefficient. 0.0 = no bounce. 1.0 = perfect reflection. >1.0 = super bounce (springs).
@export var bounciness: float = 0.0

## Knockback multiplier. 0.0 = no knockback. 1.0 = base force. 2.0 = double.
@export var knockback: float = 0.0


## Returns the contact normal in world space, accounting for entity rotation.
func get_contact_normal() -> Vector2:
	return facing.rotated(get_parent().rotation)


## Returns the entity node that owns this surface.
## Assumes the surface is a direct child of the entity.
func get_owner_entity() -> Node2D:
	return get_parent()


## Convenience: returns true if this surface can deal damage.
func is_offensive() -> bool:
	return damage_value > 0


## Convenience: returns true if this surface can block damage.
func is_defensive() -> bool:
	return shield_value > 0


## Convenience: returns true if this surface reflects velocity.
func is_bouncy() -> bool:
	return bounciness > 0.0
