@tool
extends Area2D

@onready var label = %Label

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if Engine.is_editor_hint():
		var groups = get_groups()
		label.text = ", ".join(groups) if groups.size() > 0 else "no groups"
	else:
		hide()
