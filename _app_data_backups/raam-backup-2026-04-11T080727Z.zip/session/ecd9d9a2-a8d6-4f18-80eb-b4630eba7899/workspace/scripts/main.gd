extends Node

var main_menu_scene = preload("res://scenes/main_menu_backdrop.tscn")
var level1_scene = preload("res://scenes/stage1.tscn")
var debug_scene = preload("res://scenes/test_stage.tscn")

@onready var stage = %Stage
@onready var player_camera = %PlayerCamera
@onready var menu = %RootMenu

func _ready() -> void:
	var main_menu =  main_menu_scene.instantiate()
	stage.add_child(main_menu)
	player_camera.follow_target=main_menu

func _input(event):
	if event.is_action_pressed("Menu"):
		menu.visible = !menu.visible
		if menu.visible:
			get_tree().paused = true
		else:
			get_tree().paused = false
	if menu.visible and event.is_action_pressed("Debug"):
		switch_to_scene(debug_scene)

func _on_new_button_pressed() -> void:
		switch_to_scene(level1_scene)

func switch_to_scene(scene):
	get_tree().paused = false
	for child in stage.get_children():
		child.queue_free()
		await child.tree_exited
	menu.hide()
	stage.add_child(scene.instantiate())
	player_camera.follow_target = null
	var player = get_tree().get_nodes_in_group("player")[0]
	var spawn_point = get_tree().get_nodes_in_group("spawn_point")[0]
	player_camera.follow_target = player
	player.position = spawn_point.position
