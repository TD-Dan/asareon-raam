extends Node

class_name StateMachine

@export var states : Array[String]

## Emitted when a state is being exitted (emitted right before state_entered)
signal state_exiting(state:String)

## Emitted when a new state is entered
signal state_entered(state:String)

var current_state : String:
	set(v):
		set_state(v)
	get:
		return _current_state

var _current_state : String
var _previous_state : String

## Returns true if current state is 'state'. Raises warning if 'state' does not exist
func is_state(state:String):
	if _current_state == state:
		return true
	if states.has(state):
		return false
	else:
		print("Testing for non existing state \"%s\"" % state)
		print_stack()

## Returns true if previous state was 'state'. Raises warning if 'state' does not exist
func previous_state_was(state:String):
	if _previous_state == state:
		return true
	if states.has(_previous_state):
		return false
	else:
		print("Testing for non existing previous state \"%s\"" % state)
		print_stack()

## Set the state to a new one. Must be one of the preset states in the 'states' array or will warn. If 'warn_already_set' is true will warn if same state is re entered.
func set_state(target_state:String, warn_already_set:bool = false):
	if target_state == _current_state:
		if not warn_already_set:
			return
		print("Trying to enter already active state \"%s\"" % target_state)
		print_stack()
		return
	
	if not states.has(target_state):
		print("Trying to enter non existing state \"%s\"" % target_state)
		print_stack()
		return
		
	#print("Changing from %s to %s" % [_current_state, target_state])
	
	state_exiting.emit(_current_state)
	_previous_state = _current_state
	_current_state = target_state
	state_entered.emit(_current_state)
