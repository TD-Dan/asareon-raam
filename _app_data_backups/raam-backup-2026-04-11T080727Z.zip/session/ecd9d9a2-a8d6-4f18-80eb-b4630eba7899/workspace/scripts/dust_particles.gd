extends GPUParticles2D


@export var emit_time = 0.2

var _emit_timer = 0.0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	if _emit_timer > emit_time:
		emitting = false
	_emit_timer += delta


func emit_dust():
	_emit_timer = 0.0
	#process_material.color = color
	emitting = true
	#dont update position, just piggypack the player
	#self.position = pos
