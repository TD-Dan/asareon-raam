# Raam Architecture Comprehension Report

## The Big Picture

Raam is a Kotlin Multiplatform + Compose Multiplatform application with a unidirectional data flow architecture. Everything flows through a single Store via typed Action objects. Features are absolutely decoupled -- they never import each other, communicating only through the action bus with JSON payloads. All action contracts are declared in manifest files and compiled to ActionRegistry.kt at build time.

## The Layer Cake

- L3 Actors: AgentRuntime, CommandBot
- L2 Scaffolding: Session
- L1 Services: Settings, Gateway, KnowledgeGraph
- L0 Foundation: Core, FileSystem, System/Store

Dependencies flow strictly downward. Siblings may interact. This is the structural law.

## The Action Bus Pipeline

Every dispatched action passes through:
1. Schema Lookup (is this a real action?)
2. Targeted Validation (correct routing flags?)
3. Originator Validation (is the caller registered?)
4. Authorization (public vs private action?)
5. Permission Guard (does the caller have the right grants?)
6. Lifecycle Guard (is this action allowed in the current phase?)
7. Route, Reduce, Side Effects

Guards 1-4 and 6 reject silently. Guard 5 (permissions) broadcasts core.PERMISSION_DENIED. Known limitation: silent guard failures mean callers waiting for responses can hang indefinitely.

## Key Architectural Properties

- Reducers are pure. No I/O, no dispatching. State in, state out.
- Side effects are synchronous on the dispatch thread. Async work requires launching coroutines.
- FileSystem is the universal persistence layer at L0. Every feature that touches disk goes through filesystem.READ/WRITE/LIST.
- Settings Feature manages all app config. Features register definitions via settings.ADD at startup; values are broadcast via settings.VALUE_CHANGED.
- Feature identities (uuid = null) bypass permission checks entirely. Ephemeral identities (agents, users) are subject to the full guard.
- Lifecycle sequence: BOOTING, INITIALIZING, RUNNING, CLOSING, SHUTDOWN. During INITIALIZING, features register settings definitions. No async work.
- PlatformDependencies abstracts all OS-specific I/O. Features never touch platform APIs directly.

## Testing Architecture

Five tiers: T1 (pure unit), T2 (feature + Store contract), T3 (multi-feature peer), T4 (full pipeline), T5 (real platform). TestEnvironment builder + RecordingStore for T2+. All tests in commonTest. Diagnostic-first failure via runAndLogOnFailure.

---

# Mapping to the Backup Feature

## 1. Feature Placement: L1 (Services)

Backup is a domain-specific service providing a capability to the system. It depends on L0 (FileSystem for I/O, Core for lifecycle) and L1 siblings (Settings for configuration). Nothing above it depends on it. L1 is the right home.

## 2. Feature Contract

A new BackupFeature implementing the Feature interface:
- BackupState -- tracks backup list, current operation status, configuration
- Reducer -- pure state transitions for backup operations
- Side Effects -- delegates to FileSystem for actual zip creation/extraction, listens for Settings changes
- ComposableProvider -- the Backup management UI

## 3. Action Manifest (backup.actions.json)

Preliminary action design:

- backup.CREATE (Public, Command) -- Trigger manual backup creation
- backup.RESTORE (Public, Command) -- Restore from a specific backup
- backup.DELETE (Public, Command) -- Delete a specific backup
- backup.LIST (Private, Internal) -- Refresh backup list from disk
- backup.BACKUP_CREATED (Private, Event) -- Broadcast after successful backup
- backup.BACKUP_FAILED (Private, Event) -- Broadcast after failed backup
- backup.RESTORE_COMPLETED (Private, Event) -- Broadcast after successful restore

Permissions needed: backup:manage (CAUTION) -- create, delete, restore backups

## 4. Startup Integration -- The Critical Question

The backup must run BEFORE any data modifications -- i.e., during or before INITIALIZING. But the current lifecycle says INITIALIZING is for synchronous setup (registering settings definitions, no async work). A full zip of the data directory is I/O-heavy and potentially slow.

Options:

Option A: Pre-lifecycle backup. The backup runs before the Store lifecycle even begins -- at the AppContainer or host application level. This is outside the action bus entirely. It guarantees nothing touches data before the backup completes, but it violates the everything-flows-through-the-Store principle.

Option B: New lifecycle phase. Add a BACKING_UP phase between BOOTING and INITIALIZING. The Store allows only backup-related actions during this phase. Clean, principled, but modifies the core lifecycle.

Option C: Early INITIALIZING with ordering. Backup runs first during INITIALIZING via feature list ordering (BackupFeature listed before all others). Relies on the deterministic-but-not-contractually-guaranteed feature order. Fragile.

Option D: INITIALIZING with explicit sequencing. BackupFeature runs its backup during INITIALIZING and dispatches a backup.STARTUP_COMPLETE event. Other features that modify data wait for this event before proceeding. Principled but requires coordination.

My lean: Option A or B. Option A is pragmatic -- the backup is really a pre-application-startup safety net, not a feature-level concern. Option B is architecturally cleaner but more invasive.

## 5. The Startup View

A general Startup View showing log output. This would live in Core (L0) since it is UI infrastructure. It would display during BOOTING/INITIALIZING (and potentially the new BACKING_UP phase if we go with Option B). The log output would come from PlatformDependencies logging.

## 6. Zip Support in FileSystem

FileSystem currently handles text and binary file I/O. Zip support would mean new actions:
- filesystem.ZIP -- compress a directory to a zip file
- filesystem.UNZIP -- extract a zip file to a directory

These would be L0 capabilities available to any feature.

## 7. Testing Strategy

- T1: Reducer logic -- state transitions for backup list management, configuration changes
- T2: Contract tests -- backup.CREATE produces backup.BACKUP_CREATED or backup.BACKUP_FAILED, permission checks work, ACTION_RESULT published correctly
- T3: Peer tests -- Settings integration (config changes propagate), FileSystem integration (zip operations)
- T5: Platform test -- real filesystem backup and restore roundtrip

---

# What I Still Need to Know

1. The data directory structure. What specifically lives in the Raam data folder? I know HKGs, sessions, settings, but what is the actual file tree?
2. Existing lifecycle hooks. Is there a pre-Store initialization point where backup could naturally fit (Option A)?
3. FileSystem current capabilities. Does it already have binary file support, or only text? Does PlatformDependencies expose directory-level operations (copy, zip)?
4. Settings registration pattern. What does a settings.ADD call look like in practice for a feature registering its config?
