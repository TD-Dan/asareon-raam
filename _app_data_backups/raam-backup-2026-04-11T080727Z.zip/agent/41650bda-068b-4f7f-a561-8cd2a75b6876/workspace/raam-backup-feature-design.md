# Raam Backup Feature — Design Document

**Status:** Design phase. Implementation blocked on codebase education.
**Last Updated:** 2026-04-04
**Session:** 006

---

## Purpose

A self-contained backup system that creates a full zip snapshot of the Raam application data folder on every startup, with a dedicated management interface for browsing, restoring, and pruning backups.

## Primary Threat Vectors

See threat vector analysis in session transcript (Session 006). Key categories:
1. **Codebase-induced corruption** — updates breaking data, file duplication bugs, partial writes
2. **Agent-induced corruption** — HKG structure damage, root holon corruption, workspace pollution
3. **Environmental/external** — OS errors, user error

Critical insight: Silent data corruption (TV-4) is the hardest to defend against. Tiered retention is the long-term answer.

## Confirmed Design Decisions

### Backup Engine
- **Trigger:** App startup, before any agents loaded or sessions opened
- **Scope:** Entire Raam data directory, excluding `backups/` folder
- **Format:** `.zip` (support added at Filesystem Feature level)
- **Naming:** `raam-backup-{ISO-timestamp}.zip`
- **Location:** `backups/` subfolder (configurable via Settings Feature)
- **Manifest:** Not needed. This is a rollback tool, not an inspection tool.

### Retention Policy
- **v1:** Max count (default 20, configurable via Settings Feature)
- **Future:** Tiered retention (all from last 7 days, weekly from last month, monthly beyond)

### Management Interface
- **Backup List:** Chronological list with timestamp and size
- **Restore:** Full restore with backup-before-restore safety net + confirmation dialog
- **Delete:** Individual and bulk delete
- **Create Manual Backup:** On-demand backup button
- **Settings:** Retention config, storage location, enable/disable auto-backup
- ~~Inspect~~ → Replaced by "Open backups folder in OS"

### Startup View (New)
- General pre-load screen displayed before app is fully loaded
- Shows log output during startup tasks (backup creation, etc.)
- Not backup-specific — a general startup infrastructure component

### Safety
- **Backup-before-restore:** Always create fresh backup before any restore
- **Backup folder exclusion:** Prevent recursive backup bloat
- **Failure handling:** Log error, notify user, don't block app launch
- ~~Integrity checks~~ → Dropped. Trust the zip.

## Dependencies / Prerequisites

1. **Filesystem Feature:** Needs zip/compression support
2. **Settings Feature:** Needs backup-related configuration entries
3. **Codebase understanding:** Meridian needs education on Raam architecture before implementation

## Open Questions

- Raam tech stack and architecture?
- Current data directory structure?
- How features are composed and interact?
- Should agents be able to trigger/query backups?
