# BackupFeature — Detailed Implementation Design (Updated)

**Status:** Design refined with Daniel's feedback
**Session:** 006

---

## 1. Architecture Overview

BackupFeature is an L1 (platform services) feature that provides automatic startup snapshots and a management UI for browsing, restoring, and pruning backups.

### Key Architectural Decisions

- Uses `preInit()` for startup snapshots (runs before Store is operational)
- Uses `platformDependencies` directly for all file I/O in `preInit()` (no action bus)
- Uses a **hint file** (`_backups/.backup-config`) to know whether auto-backup is enabled without reading encrypted settings
- Uses the action bus for runtime operations (manual backup, restore, delete, settings)
- Integrates with SettingsFeature for user-facing configuration
- Does NOT use FileSystemFeature's sandboxed workspace — operates on APP_ZONE root directly
- On restore: creates safety backup, extracts, auto-restarts app
- On restart after restore: skips backup (via `.skip-next-backup` hint file)

### File Structure on Disk

```
{APP_ZONE}/
  _backups/                          <- BackupFeature's storage directory
    .backup-config                   <- Hint file (auto-backup enabled, max count)
    .skip-next-backup                <- Transient flag: skip next preInit backup
    raam-backup-2026-04-04T140000Z.zip
    raam-backup-2026-04-04T120000Z.zip
    raam-backup-2026-04-03T090000Z.zip
  agent/                             <- Agent data (backed up)
  session/                           <- Session data (backed up)
  settings/                          <- Settings data (backed up)
  knowledgegraph/                    <- HKG data (backed up)
```

**Directory name:** `_backups` (underscore prefix to sort before feature dirs)
**Naming:** `raam-backup-{ISO-8601-timestamp}.zip` (colons removed)
**Backup scope:** Everything in APP_ZONE EXCEPT `_backups/` directory itself.
**Sort:** Lexicographic = chronological (by timestamp format design).

### Hint File: .backup-config

Plain text JSON, unencrypted. Written by BackupFeature during SYSTEM_INITIALIZING when settings are synced. Read by preInit() on next startup.

```json
{
  "autoBackupEnabled": true,
  "maxBackups": 20
}
```

If the file doesn't exist (fresh install), defaults apply: auto-backup = true, max = 20.

### Hint File: .skip-next-backup

Empty marker file. Created by restore process before triggering restart. preInit() checks for it, skips backup if present, then deletes the marker.

### Complete Startup Sequence

```
1. PlatformDependencies instantiated
2. AppContainer constructs features (with dependencies) + Store
3. initFeatureLifecycles():
   a. Seed identities
   b. features.forEach { it.preInit() }
      BackupFeature.preInit():
        - Check .skip-next-backup -> if exists, delete it, return
        - Read .backup-config -> if autoBackupEnabled = false, return
        - Create zip snapshot of APP_ZONE (excluding _backups/)
   c. features.forEach { it.init(this) }
   d. lifecycleStarted = true
4. LaunchedEffect dispatches SYSTEM_INITIALIZING
   BackupFeature handles:
     - Register settings with SettingsFeature
     - Scan _backups/ directory, populate state
     - Apply retention pruning (using maxBackups from .backup-config)
5. LaunchedEffect dispatches SYSTEM_RUNNING
```

### preInit() KDoc Contract

```kotlin
/**
 * Called before Store initialization and before any feature's init().
 * 
 * Contract:
 * - The Store is NOT operational. Do not dispatch actions.
 * - Use only constructor-injected dependencies (platformDependencies).
 * - Must be idempotent and safe to call multiple times.
 * - Must not modify application state that other features depend on.
 * - Must handle its own errors. Never throw — a preInit failure
 *   must not prevent app startup.
 * - Should complete quickly. This blocks the UI thread.
 */
fun preInit() {}
```