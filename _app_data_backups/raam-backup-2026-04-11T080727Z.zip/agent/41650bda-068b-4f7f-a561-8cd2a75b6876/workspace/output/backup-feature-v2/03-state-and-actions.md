## 4. State Model

```kotlin
@Serializable
data class BackupState(
    // Backup inventory
    val backups: List<BackupEntry> = emptyList(),

    // Operation status
    val isCreatingBackup: Boolean = false,
    val isRestoringBackup: Boolean = false,
    val lastError: String? = null,
    val lastBackupResult: BackupResult? = null,

    // Settings (hydrated from SettingsFeature)
    val maxBackups: Int = 20,
    val autoBackupEnabled: Boolean = true,

    // Pending restore (awaiting user confirmation)
    val pendingRestoreFileName: String? = null,
    val pendingRestoreRequestId: String? = null
) : FeatureState

@Serializable
data class BackupEntry(
    val fileName: String,
    val timestamp: String,       // ISO-8601 UTC
    val sizeBytes: Long,
    val path: String             // Relative to _backups dir
)

@Serializable
enum class BackupResult { SUCCESS, FAILED }
```

## 5. Actions

### Internal Actions

| Action | Purpose |
|--------|--------|
| backup.REFRESH_LIST | Scan _backups dir, update inventory |
| backup.LIST_LOADED | Carries scanned list into reducer |
| backup.CREATE_STARTED | Sets isCreatingBackup = true |
| backup.CREATE_COMPLETED | Sets isCreatingBackup = false, updates result |
| backup.RESTORE_STARTED | Sets isRestoringBackup = true |
| backup.RESTORE_COMPLETED | Sets isRestoringBackup = false |
| backup.STAGE_RESTORE | Stores pending restore filename + requestId |
| backup.CLEAR_PENDING_RESTORE | Clears pending restore state |

### Public Actions

| Action | Purpose | Payload |
|--------|---------|--------|
| backup.CREATE | Manual backup on demand | (none) |
| backup.RESTORE | Restore from backup | { fileName } |
| backup.DELETE | Delete specific backup | { fileName } |
| backup.PRUNE | Run retention pruning | (none) |
| backup.OPEN_FOLDER | Open _backups dir in OS | (none) |