## 7. Reducer

```kotlin
override fun reducer(state: FeatureState?, action: Action): FeatureState? {
    val current = state as? BackupState ?: BackupState()
    val payload = action.payload

    when (action.name) {
        BACKUP_LIST_LOADED -> {
            val entries = decode<List<BackupEntry>>(payload)
            return current.copy(backups = entries, lastError = null)
        }
        BACKUP_CREATE_STARTED -> {
            return current.copy(isCreatingBackup = true, lastError = null)
        }
        BACKUP_CREATE_COMPLETED -> {
            return current.copy(
                isCreatingBackup = false,
                lastBackupResult = payload.result,
                lastError = payload.error
            )
        }
        BACKUP_RESTORE_STARTED -> {
            return current.copy(isRestoringBackup = true, lastError = null)
        }
        BACKUP_RESTORE_COMPLETED -> {
            return current.copy(isRestoringBackup = false)
        }
        BACKUP_STAGE_RESTORE -> {
            return current.copy(
                pendingRestoreFileName = payload.fileName,
                pendingRestoreRequestId = payload.requestId
            )
        }
        BACKUP_CLEAR_PENDING_RESTORE -> {
            return current.copy(
                pendingRestoreFileName = null,
                pendingRestoreRequestId = null
            )
        }
        SETTINGS_LOADED -> {
            return current.copy(
                maxBackups = extractSetting(payload, settingKeyMaxBackups, current.maxBackups),
                autoBackupEnabled = extractSetting(payload, settingKeyAutoBackup, current.autoBackupEnabled)
            )
        }
        SETTINGS_VALUE_CHANGED -> {
            when (payload.key) {
                settingKeyMaxBackups -> return current.copy(maxBackups = payload.value.toInt())
                settingKeyAutoBackup -> return current.copy(autoBackupEnabled = payload.value.toBoolean())
            }
        }
    }
    return current
}
```

## 8. Settings Registration

```kotlin
private fun registerSettings(store: Store) {
    store.deferredDispatch(identity.handle, Action(
        SETTINGS_ADD, buildJsonObject {
            put("key", settingKeyMaxBackups)
            put("type", "NUMERIC_LONG")
            put("label", "Maximum Backups")
            put("description", "Max backup snapshots to retain. Oldest pruned automatically.")
            put("section", "Backup")
            put("defaultValue", defaultMaxBackups.toString())
        }))
    store.deferredDispatch(identity.handle, Action(
        SETTINGS_ADD, buildJsonObject {
            put("key", settingKeyAutoBackup)
            put("type", "BOOLEAN")
            put("label", "Auto-Backup on Startup")
            put("description", "Create a backup snapshot every time the app starts.")
            put("section", "Backup")
            put("defaultValue", "true")
        }))
}
```

## 9. Retention Policy — Count-Based Pruning

```kotlin
private fun pruneToMaxCount(maxCount: Int) {
    val backupsDir = getBackupsDir()
    val backupFiles = platformDependencies.listDirectory(backupsDir)
        .filter { !it.isDirectory && it.path.endsWith(backupExtension) }
        .sortedBy { platformDependencies.getFileName(it.path) }

    if (backupFiles.size > maxCount) {
        val toDelete = backupFiles.take(backupFiles.size - maxCount)
        toDelete.forEach { entry ->
            try {
                platformDependencies.deleteFile(entry.path)
                platformDependencies.log(LogLevel.INFO, identity.handle,
                    "Pruned: ${platformDependencies.getFileName(entry.path)}")
            } catch (e: Exception) {
                platformDependencies.log(LogLevel.WARN, identity.handle,
                    "Prune failed: ${e.message}", e)
            }
        }
    }
}
```

Future: tiered retention (daily/weekly/monthly) — not in v1.