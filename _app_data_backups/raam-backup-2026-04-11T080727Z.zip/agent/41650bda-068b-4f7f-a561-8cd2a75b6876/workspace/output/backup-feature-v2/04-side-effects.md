## 6. Side Effects — handleSideEffects()

Pseudocode using Raam conventions (buildJsonObject, deferredDispatch, etc.)

### SYSTEM_INITIALIZING
```kotlin
// Register settings with SettingsFeature
registerSettings(store)
// Scan backup directory and populate state
store.deferredDispatch(identity.handle, Action(BACKUP_REFRESH_LIST))
```

### SETTINGS_LOADED / SETTINGS_VALUE_CHANGED
```kotlin
// Sync hint file with actual settings
val state = newState as? BackupState ?: return
writeBackupConfig(BackupConfig(
    autoBackupEnabled = state.autoBackupEnabled,
    maxBackups = state.maxBackups
))
// Prune if over limit
if (state.backups.size > state.maxBackups) {
    store.deferredDispatch(identity.handle, Action(BACKUP_PRUNE))
}
```

### BACKUP_REFRESH_LIST
```kotlin
val entries = scanBackupsDirectory()
store.deferredDispatch(identity.handle,
    Action(BACKUP_LIST_LOADED, payload = entries))
```

### BACKUP_CREATE
```kotlin
store.deferredDispatch(identity.handle, Action(BACKUP_CREATE_STARTED))
try {
    val backupsDir = getBackupsDir()
    val timestamp = generateTimestamp()
    val fileName = "$backupPrefix$timestamp$backupExtension"
    val path = "$backupsDir$sep$fileName"
    platformDependencies.createZipArchive(path, appZoneRoot, backupsDirName)
    store.deferredDispatch(identity.handle,
        Action(BACKUP_CREATE_COMPLETED, result=SUCCESS))
    store.deferredDispatch(identity.handle, Action(BACKUP_REFRESH_LIST))
    store.deferredDispatch(identity.handle, Action(BACKUP_PRUNE))
} catch (e: Exception) {
    log(ERROR, "Manual backup failed: ${e.message}")
    store.deferredDispatch(identity.handle,
        Action(BACKUP_CREATE_COMPLETED, result=FAILED, error=e.message))
}
```

### BACKUP_RESTORE (Phase 1: Request confirmation)
```kotlin
val fileName = payload.fileName
val requestId = platformDependencies.generateUUID()
// Stage in state
store.deferredDispatch(identity.handle,
    Action(BACKUP_STAGE_RESTORE, { fileName, requestId }))
// Show confirmation dialog via CoreFeature
store.deferredDispatch(identity.handle,
    Action(CORE_SHOW_CONFIRMATION_DIALOG, {
        title: "Restore Backup?",
        text: "This will replace ALL current data with '$fileName'.\n" +
              "A safety backup will be created first.\n" +
              "The app will restart after restore.",
        confirmButtonText: "Restore",
        requestId: requestId
    }))
```

### CORE_RETURN_CONFIRMATION (Phase 2: Execute restore)
```kotlin
val state = newState as? BackupState ?: return
val pendingFile = state.pendingRestoreFileName ?: return
val pendingRequestId = state.pendingRestoreRequestId ?: return

// Verify this confirmation is for our pending restore
if (payload.requestId != pendingRequestId) return

if (payload.confirmed) {
    store.deferredDispatch(identity.handle, Action(BACKUP_RESTORE_STARTED))
    try {
        val backupsDir = getBackupsDir()
        val sep = platformDependencies.pathSeparator
        
        // 1. Safety backup before restore
        val safetyTimestamp = generateTimestamp()
        val safetyName = "raam-backup-pre-restore-$safetyTimestamp$backupExtension"
        platformDependencies.createZipArchive(
            "$backupsDir$sep$safetyName", appZoneRoot, backupsDirName)
        
        // 2. Write skip marker (so restart doesn't create another backup)
        writeSkipMarker()
        
        // 3. Extract the selected backup over APP_ZONE
        val backupPath = "$backupsDir$sep$pendingFile"
        platformDependencies.extractZipArchive(
            zipPath = backupPath,
            targetDirectory = appZoneRoot
        )
        
        // 4. Auto-restart the app
        store.deferredDispatch(identity.handle,
            Action(BACKUP_RESTORE_COMPLETED))
        platformDependencies.restartApplication()
        
    } catch (e: Exception) {
        log(ERROR, "Restore failed: ${e.message}")
        store.deferredDispatch(identity.handle,
            Action(BACKUP_RESTORE_COMPLETED))
        // Safety backup still exists for recovery
    }
}
// Always clear pending state
store.deferredDispatch(identity.handle, Action(BACKUP_CLEAR_PENDING_RESTORE))
```

### BACKUP_DELETE
```kotlin
val fileName = payload.fileName
val backupsDir = getBackupsDir()
try {
    platformDependencies.deleteFile("$backupsDir$sep$fileName")
    store.deferredDispatch(identity.handle, Action(BACKUP_REFRESH_LIST))
} catch (e: Exception) {
    log(ERROR, "Delete failed: ${e.message}")
}
```

### BACKUP_PRUNE
```kotlin
val state = newState as? BackupState ?: return
pruneToMaxCount(state.maxBackups)
store.deferredDispatch(identity.handle, Action(BACKUP_REFRESH_LIST))
```

### BACKUP_OPEN_FOLDER
```kotlin
platformDependencies.openFolderInExplorer(getBackupsDir())
```