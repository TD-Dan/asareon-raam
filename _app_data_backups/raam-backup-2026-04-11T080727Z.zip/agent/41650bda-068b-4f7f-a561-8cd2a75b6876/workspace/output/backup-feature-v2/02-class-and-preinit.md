## 2. BackupFeature Class Structure

```kotlin
package asareon.raam.feature.backup

class BackupFeature(
    private val platformDependencies: PlatformDependencies
) : Feature {
    override val identity = Identity(
        uuid = null,
        handle = "backup",
        localHandle = "backup",
        name = "Backup"
    )
    override val composableProvider = BackupComposableProvider()

    // Settings keys
    private val settingKeyMaxBackups = "backup.maxBackups"
    private val settingKeyAutoBackup = "backup.autoBackupEnabled"

    // Defaults
    private val defaultMaxBackups = 20
    private val defaultAutoBackup = true
    private val backupsDirName = "_backups"
    private val backupPrefix = "raam-backup-"
    private val backupExtension = ".zip"
    private val configFileName = ".backup-config"
    private val skipMarkerFileName = ".skip-next-backup"
}
```

**Registration in AppContainer:**
```kotlin
// In AppContainer.kt features list:
BackupFeature(platformDependencies)
```

---

## 3. preInit() — Startup Snapshot

```kotlin
override fun preInit() {
    val sep = platformDependencies.pathSeparator
    val appZoneRoot = platformDependencies.getBasePathFor(BasePath.APP_ZONE)
    val backupsDir = "$appZoneRoot$sep$backupsDirName"

    // Ensure backups directory exists
    if (!platformDependencies.fileExists(backupsDir)) {
        platformDependencies.createDirectories(backupsDir)
    }

    // Check skip marker (post-restore restart)
    val skipMarkerPath = "$backupsDir$sep$skipMarkerFileName"
    if (platformDependencies.fileExists(skipMarkerPath)) {
        platformDependencies.deleteFile(skipMarkerPath)
        platformDependencies.log(LogLevel.INFO, identity.handle,
            "Skip marker found. Skipping post-restore backup.")
        return
    }

    // Read hint file to check if auto-backup is enabled
    val config = readBackupConfig(backupsDir)
    if (!config.autoBackupEnabled) {
        platformDependencies.log(LogLevel.INFO, identity.handle,
            "Auto-backup disabled. Skipping startup snapshot.")
        return
    }

    // Generate timestamped backup filename
    val timestamp = generateTimestamp()
    val backupFileName = "$backupPrefix$timestamp$backupExtension"
    val backupPath = "$backupsDir$sep$backupFileName"

    try {
        platformDependencies.log(LogLevel.INFO, identity.handle,
            "Creating startup backup: $backupFileName")
        platformDependencies.createZipArchive(
            outputPath = backupPath,
            sourceDirectory = appZoneRoot,
            excludeDirectory = backupsDirName
        )
        platformDependencies.log(LogLevel.INFO, identity.handle,
            "Startup backup created: $backupFileName")
    } catch (e: Exception) {
        // NEVER block app startup on backup failure
        platformDependencies.log(LogLevel.ERROR, identity.handle,
            "Startup backup failed: ${e.message}", e)
    }
}
```

### Hint File Operations

```kotlin
private data class BackupConfig(
    val autoBackupEnabled: Boolean = true,
    val maxBackups: Int = 20
)

private fun readBackupConfig(backupsDir: String): BackupConfig {
    val sep = platformDependencies.pathSeparator
    val configPath = "$backupsDir$sep$configFileName"
    return try {
        if (!platformDependencies.fileExists(configPath)) return BackupConfig()
        val content = platformDependencies.readFileContent(configPath)
        Json.decodeFromString<BackupConfig>(content)
    } catch (e: Exception) {
        platformDependencies.log(LogLevel.WARN, identity.handle,
            "Could not read backup config, using defaults: ${e.message}")
        BackupConfig()
    }
}

private fun writeBackupConfig(config: BackupConfig) {
    val sep = platformDependencies.pathSeparator
    val backupsDir = getBackupsDir()
    val configPath = "$backupsDir$sep$configFileName"
    try {
        val content = Json.encodeToString(config)
        platformDependencies.writeFileContent(configPath, content)
    } catch (e: Exception) {
        platformDependencies.log(LogLevel.WARN, identity.handle,
            "Could not write backup config: ${e.message}")
    }
}

private fun writeSkipMarker() {
    val sep = platformDependencies.pathSeparator
    val backupsDir = getBackupsDir()
    val markerPath = "$backupsDir$sep$skipMarkerFileName"
    try {
        platformDependencies.writeFileContent(markerPath, "")
    } catch (e: Exception) {
        platformDependencies.log(LogLevel.WARN, identity.handle,
            "Could not write skip marker: ${e.message}")
    }
}
```

### Timestamp Generation

```kotlin
private fun generateTimestamp(): String {
    return Clock.System.now()
        .toString()
        .replace(":", "")
        .substringBefore('.')
        .plus("Z")
}
```