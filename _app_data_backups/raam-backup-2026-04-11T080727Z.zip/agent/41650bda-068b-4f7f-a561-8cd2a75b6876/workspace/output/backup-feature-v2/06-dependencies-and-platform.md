## 10. Error Handling Summary

| Scenario | Behavior |
|----------|----------|
| preInit() backup fails | Log ERROR, continue startup. Never block. |
| preInit() can't create _backups dir | Log ERROR, continue. Feature degraded. |
| Hint file corrupt/missing | Use defaults (auto=true, max=20). |
| Manual backup fails | Update state FAILED, show error in UI. |
| Restore fails | Log ERROR, show in UI. Safety backup exists. |
| Delete fails | Log ERROR, show toast. |
| _backups dir missing | Create on demand. |
| Corrupt backup zip | No special handling. User deletes via UI. |
| Retention pruning fails | Log WARN, backups accumulate until next prune. |
| Skip marker can't be written | Log WARN. Worst case: one extra backup after restore. |

## 11. PlatformDependencies — New Methods Required

### Already Exists
| Method | Notes |
|--------|-------|
| getBasePathFor(APP_ZONE) | Root of all app data |
| listDirectory(path) | Returns List<FileEntry> |
| createDirectories(path) | Full path creation |
| deleteFile(path) | Single file deletion |
| fileExists(path) | Existence check |
| readFileContent(path) | Read as string |
| writeFileContent(path, content) | Write string to file |
| openFolderInExplorer(path) | OS file browser |
| generateUUID() | For confirmation requestIds |
| getFileName(path) | Extract filename from path |
| createZipArchive(...) | Exists but signature needs verification |
| log(level, tag, message) | Logging |

### Needs To Be Added
| Method | Signature | Priority |
|--------|-----------|----------|
| fileSize(path) | `fun fileSize(path: String): Long` | Medium — for backup list UI |
| extractZipArchive(zipPath, targetDir) | `fun extractZipArchive(zipPath: String, targetDirectory: String)` | HIGH — required for restore |
| restartApplication() | `fun restartApplication()` | HIGH — required for auto-restart after restore |

### createZipArchive — Signature Verification Needed
Existing method needs to support:
- Zipping an entire directory tree
- Excluding a subdirectory by name (the _backups dir itself)

Current signature (from earlier backup system): **needs Daniel to verify**.
If it only supports single files or doesn't support exclusion, it needs to be extended.

## 12. Restore Flow — Complete Sequence

```
1. User clicks "Restore" on a backup entry
2. backup.RESTORE dispatched with { fileName }
3. BackupFeature stages pending restore, shows confirmation dialog
4. User confirms
5. CORE_RETURN_CONFIRMATION received
6. BackupFeature:
   a. Creates safety backup (raam-backup-pre-restore-{timestamp}.zip)
   b. Writes .skip-next-backup marker file
   c. Extracts selected backup zip over APP_ZONE (excluding _backups/)
   d. Calls platformDependencies.restartApplication()
7. App restarts
8. preInit() finds .skip-next-backup, deletes it, skips backup
9. Normal startup continues with restored data
```

## 13. Open Design Question

**Restore extraction behavior:** When extracting the backup zip over APP_ZONE, should we:
- **Option A:** Delete all existing APP_ZONE content first (clean restore)
- **Option B:** Overwrite in place (existing files not in backup remain)

Option A is the safer choice — it ensures the restored state exactly matches the backup. Option B risks leftover files causing unexpected behavior. Recommendation: **Option A** (delete then extract), excluding _backups/ of course.