# SessionContextFormatter.kt — Two Changes

## Change 1: Render [🔒] in message header

### Location
`buildSessionContent()` method, the message header line.

### Current code:
```kotlin
val formattedTimestamp = platformDependencies.formatIsoTimestamp(msg.timestamp)
append(ContextDelimiters.h3("${msg.senderName} (${msg.senderId}) @ $formattedTimestamp"))
```

### New code:
```kotlin
val formattedTimestamp = platformDependencies.formatIsoTimestamp(msg.timestamp)
val lockIndicator = if (msg.isLocked) " [🔒]" else ""
append(ContextDelimiters.h3("${msg.senderName} (${msg.senderId}) @ $formattedTimestamp$lockIndicator"))
```

---

## Change 2: Add lock symbol explanation to sessions header

### Location
`buildSessionsHeader()` method, after the line:
```kotlin
appendLine("Each message in the conversation is wrapped with sender headers (name, id, timestamp).")
```

### Add this line immediately after:
```kotlin
appendLine("Locked messages display [🔒] after the timestamp in their header.")
```
