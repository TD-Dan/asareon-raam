# AgentState.kt — GatewayMessage Change

## Location
`feature/agent/AgentState.kt` — the `GatewayMessage` data class

## Current code:
```kotlin
@Serializable
data class GatewayMessage(
    val role: String,
    val content: String,
    val senderId: String,
    val senderName: String,
    val timestamp: Long
)
```

## New code (add isLocked field):
```kotlin
@Serializable
data class GatewayMessage(
    val role: String,
    val content: String,
    val senderId: String,
    val senderName: String,
    val timestamp: Long,
    val isLocked: Boolean = false
)
```

The `= false` default ensures backward compatibility with all existing construction sites.
