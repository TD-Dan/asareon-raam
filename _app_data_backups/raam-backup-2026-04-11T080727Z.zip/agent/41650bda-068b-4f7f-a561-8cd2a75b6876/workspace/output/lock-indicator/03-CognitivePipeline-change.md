# CognitivePipeline.kt — handleLedgerResponse Change

## Location
`feature/agent/CognitivePipeline.kt` — inside `handleLedgerResponse()`, 
the `enrichedMessages` mapping block.

## Current code (inside the mapNotNull lambda):
```kotlin
val entryJson = element.jsonObject
val senderId = entryJson["senderId"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
val rawContent = entryJson["rawContent"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null
val timestamp = entryJson["timestamp"]?.jsonPrimitive?.longOrNull ?: return@mapNotNull null
```

## Add after the timestamp line:
```kotlin
val isLocked = entryJson["isLocked"]?.jsonPrimitive?.booleanOrNull ?: false
```

## Then update the GatewayMessage construction at the bottom of the same block.

### Current:
```kotlin
GatewayMessage(role, rawContent, senderId, senderName, timestamp)
```

### New:
```kotlin
GatewayMessage(role, rawContent, senderId, senderName, timestamp, isLocked)
```

That's it — two lines changed in this file.
