# Lock Indicator [🔒] — Implementation Spec

## Overview
Add a `[🔒]` indicator to locked message headers in agent context so agents can
verify lock status before clearing sessions.

## Changes Required (5 touchpoints)

### 1. GatewayMessage — Add isLocked field
**File:** `feature/agent/AgentState.kt`
**Change:** Add `val isLocked: Boolean = false` to `GatewayMessage` data class.

This carries lock status from the ledger through to the context formatter.
Default `false` ensures backward compatibility with any existing construction sites.

### 2. Ledger → GatewayMessage mapping — Populate isLocked
**File:** Wherever `LedgerEntry` is converted to `GatewayMessage` (likely in
`SessionFeature.kt` or `CognitivePipeline.kt` where ledger responses are formatted).
**Change:** When constructing `GatewayMessage` from a `LedgerEntry`, set
`isLocked = entry.isLocked`.

Search for `GatewayMessage(` construction sites that reference `LedgerEntry` fields
like `senderId`, `senderName`, `timestamp` — that's where to add the mapping.

### 3. SessionContextFormatter — Render [🔒] in message header
**File:** `feature/agent/contextformatters/SessionContextFormatter.kt`
**Method:** `buildSessionContent()` — the section that builds per-message headers.
**Current line pattern:**
  append(ContextDelimiters.h3("${msg.senderName} (${msg.senderId}) @ $formattedTimestamp"))

**New line:**
  val lockIndicator = if (msg.isLocked) " [🔒]" else ""
  append(ContextDelimiters.h3("${msg.senderName} (${msg.senderId}) @ $formattedTimestamp$lockIndicator"))

This produces:
  --- Meridian (agent.meridian) @ 2026-04-05T10:24:01Z [🔒] ---
vs. the current:
  --- Meridian (agent.meridian) @ 2026-04-05T10:24:01Z ---

### 4. SessionContextFormatter — Add one-line docs to sessions header
**File:** `feature/agent/contextformatters/SessionContextFormatter.kt`
**Method:** `buildSessionsHeader()` — the block that explains message format.
**Add after the line about sender headers:**

  "Locked messages display [🔒] after the timestamp in their header."

This goes near the existing text:
  "Each message in the conversation is wrapped with sender headers (name, id, timestamp)."

### 5. session.actions.json — Update CLEAR description
**File:** `feature/session/session.actions.json`
**Action:** `session.CLEAR`
**Current summary:** "Removes all messages from a session's ledger that are neither locked nor marked doNotClear. Protected messages are preserved."
**New summary:** "Removes all messages from a session's ledger that are neither locked nor marked doNotClear. Messages marked [🔒] (locked) and entries flagged doNotClear are preserved."

## Testing
- Verify a locked message shows [🔒] in agent context header
- Verify an unlocked message does NOT show [🔒]
- Verify session.CLEAR preserves [🔒] messages
- Verify the symbol appears after locking via session.LOCK_MESSAGE
