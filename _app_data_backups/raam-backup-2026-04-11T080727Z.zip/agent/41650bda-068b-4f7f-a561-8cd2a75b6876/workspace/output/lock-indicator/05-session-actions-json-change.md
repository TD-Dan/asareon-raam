# session.actions.json — CLEAR Description Update

## Location
`feature/session/session.actions.json` — the `session.CLEAR` action entry.

## Current summary:
"Removes all messages from a session's ledger that are neither locked nor marked doNotClear. Protected messages are preserved."

## New summary:
"Removes all messages from a session's ledger that are not locked (marked [🔒])."
