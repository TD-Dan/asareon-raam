# PATCH_HOLON Integration Notes

## Files to create/modify:

### 1. New file: `JsonPatchUtils.kt`
Location: `asareon/raam/feature/knowledgegraph/JsonPatchUtils.kt`
Content: `02-json-pointer-utils.kt` from this output directory.
Contains all JSON Pointer parsing, traversal, validation, and mutation utilities.

### 2. Modify: `knowledgegraph.actions.json`
Add the action schema from `01-action-schema.json` to the `actions` array.

### 3. Modify: `KnowledgeGraphFeature.kt`
Add the side-effect handler case from `03-side-effect-handler.kt` to the
`when (action.name)` block in `handleSideEffects()`.

Add this import at the top:
```
import asareon.raam.feature.knowledgegraph.buildHolonJsonTree
import asareon.raam.feature.knowledgegraph.validatePatchOperations
import asareon.raam.feature.knowledgegraph.applyPatchOp
import asareon.raam.feature.knowledgegraph.extractPatchedComponents
```
(These may not be needed if JsonPatchUtils.kt is in the same package.)

### 4. Regenerate: `ActionRegistry`
The generated `ActionRegistry.Names` object needs a new constant:
`KNOWLEDGEGRAPH_PATCH_HOLON` mapped to `"knowledgegraph.PATCH_HOLON"`

### 5. No reducer changes needed
Like REPLACE_HOLON, PATCH_HOLON is entirely side-effect driven.
State update comes from the LOAD_PERSONA reload cycle.

## Design Decisions:

- **Validate-then-apply**: All operations validated in pass 1, applied in pass 2.
  If ANY validation fails, the entire patch is rejected with ALL errors listed.
- **Protected fields**: id, filePath, parentId, depth, sub_holons, created_at
  are blocked at the validation layer.
- **modified_at**: Auto-stamped after successful patch, not manually settable.
- **Parent sub_holon ref**: Updated if name/type/summary changes (same as REPLACE_HOLON).
- **JSON Pointer**: Full RFC 6901 compliance including ~0/~1 escape sequences.
- **Array append**: Supported via the `/-` path suffix with `add` op.
- **Immutable JsonElement**: All mutations use copy-on-write tree rebuilding.

## Testing recommendations:
- Path parsing with escapes (~0, ~1)
- Replace on existing path (success)
- Replace on non-existent path (validation error)
- Add new key to object
- Add/append to array with /-
- Remove existing key
- Remove non-existent key (validation error)
- Protected path rejection
- Multiple operations with one invalid (all rejected)
- Empty operations array (rejected)
- Deeply nested path traversal
