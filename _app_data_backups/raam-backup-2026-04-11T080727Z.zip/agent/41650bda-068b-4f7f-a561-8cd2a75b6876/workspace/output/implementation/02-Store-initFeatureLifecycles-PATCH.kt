// ============================================================================
// PATCH: Store.kt — initFeatureLifecycles()
// Replace the existing initFeatureLifecycles() method with this version.
// The ONLY change is the addition of the preInit() loop before init().
// ============================================================================

    fun initFeatureLifecycles() {
        if (!lifecycleStarted) {
            // Seed feature identities directly — no action bus needed.
            // Feature identities are structural facts known at compile time.
            // They cannot go through the action bus because during BOOTING,
            // only system.INITIALIZING is permitted (lifecycle guard).
            //
            // Default permissions from DefaultPermissions are applied here so
            // that child identities can inherit from their parent feature
            // naturally via resolveEffectivePermissions. For example, "agent"
            // gets filesystem:workspace=YES, and "agent.mercury" inherits it.
            val featureIdentities = features.associate { feature ->
                val defaults = DefaultPermissions.grantsFor(feature.identity.handle)
                val identityWithDefaults = if (defaults.isNotEmpty()) {
                    feature.identity.copy(permissions = defaults + feature.identity.permissions)
                } else {
                    feature.identity
                }
                feature.identity.handle to identityWithDefaults
            }

            // Seed AppState directly — single source of truth from the start.
            _state.value = _state.value.copy(
                identityRegistry = _state.value.identityRegistry + featureIdentities
            )

            // PRE_INIT phase: Allow features to perform pre-initialization work
            // (e.g., creating protective snapshots) before the Store is operational.
            // See Feature.preInit() KDoc for the full contract.
            features.forEach { it.preInit() }

            features.forEach { it.init(this) }
            lifecycleStarted = true
        }
    }
