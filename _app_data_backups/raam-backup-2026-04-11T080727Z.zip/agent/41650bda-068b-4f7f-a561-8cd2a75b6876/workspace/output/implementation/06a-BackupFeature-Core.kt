package asareon.raam.feature.backup

import asareon.raam.core.*
import asareon.raam.core.generated.ActionRegistry
import asareon.raam.util.BasePath
import asareon.raam.util.LogLevel
import asareon.raam.util.PlatformDependencies
import kotlinx.serialization.json.*

/**
 * ## BackupFeature
 *
 * Creates protective snapshots of application data during [preInit] and manages
 * backup creation, restoration, retention, and browsing at runtime.
 *
 * **Layer:** L1 (Platform Services)
 *
 * **Lifecycle:**
 * - [preInit]: Creates startup backup before Store is operational. Reads `.backup-config`
 *   hint file to determine if auto-backup is enabled. Checks for `.skip-next-backup`
 *   marker (written by restore flow) to skip unnecessary backup of just-restored state.
 * - [init]: No-op.
 * - `system.INITIALIZING`: Registers settings, scans backup directory, applies retention.
 * - Runtime: Handles CREATE, RESTORE, DELETE, PRUNE, OPEN_FOLDER via action bus.
 */
class BackupFeature(
    private val platformDependencies: PlatformDependencies
) : Feature {

    override val identity = Identity(uuid = null, handle = "backup", name = "Backup Manager")

    private val tag = "BackupFeature"

    // --- Path helpers ---
    private val appZonePath: String by lazy { platformDependencies.getBasePathFor(BasePath.APP_ZONE) }
    private val sep: Char get() = platformDependencies.pathSeparator
    private val backupsDir: String by lazy { "$appZonePath${sep}_backups" }
    private val configFilePath: String by lazy { "$backupsDir${sep}.backup-config" }
    private val skipMarkerPath: String by lazy { "$backupsDir${sep}.skip-next-backup" }

    // ========================================================================
    // PRE_INIT
    // ========================================================================

    override fun preInit() {
        try {
            platformDependencies.createDirectories(backupsDir)

            // Check skip marker (written by restore flow)
            if (platformDependencies.fileExists(skipMarkerPath)) {
                platformDependencies.deleteFile(skipMarkerPath)
                platformDependencies.log(LogLevel.INFO, tag,
                    "Skip marker found - skipping startup backup (post-restore restart).")
                return
            }

            // Read hint file to check if auto-backup is enabled
            if (platformDependencies.fileExists(configFilePath)) {
                try {
                    val configJson = Json.parseToJsonElement(
                        platformDependencies.readFileContent(configFilePath)
                    ).jsonObject
                    val autoEnabled = configJson["autoBackupEnabled"]
                        ?.jsonPrimitive?.booleanOrNull ?: true
                    if (!autoEnabled) {
                        platformDependencies.log(LogLevel.INFO, tag,
                            "Auto-backup disabled via hint file. Skipping startup backup.")
                        return
                    }
                } catch (e: Exception) {
                    platformDependencies.log(LogLevel.WARN, tag,
                        "Failed to read .backup-config, defaulting to auto-backup enabled.", e)
                }
            }

            // Generate timestamped filename
            val timestamp = platformDependencies
                .formatIsoTimestamp(platformDependencies.currentTimeMillis())
                .replace(":", "")
            val filename = "raam-backup-$timestamp.zip"
            val destinationPath = "$backupsDir$sep$filename"

            platformDependencies.log(LogLevel.INFO, tag, "Creating startup backup: $filename")
            platformDependencies.createZipArchive(
                sourceDirectoryPath = appZonePath,
                destinationZipPath = destinationPath,
                excludeDirectoryName = "_backups"
            )
            platformDependencies.log(LogLevel.INFO, tag,
                "Startup backup created successfully: $filename")

        } catch (e: Exception) {
            // NEVER block startup.
            platformDependencies.log(LogLevel.ERROR, tag,
                "Failed to create startup backup. Application will continue.", e)
        }
    }

    // ========================================================================
    // REDUCER
    // ========================================================================

    override fun reducer(state: FeatureState?, action: Action): FeatureState? {
        val s = state as? BackupState ?: BackupState()

        return when (action.name) {
            ActionRegistry.Names.SYSTEM_INITIALIZING -> s

            ActionRegistry.Names.BACKUP_INVENTORY_UPDATED -> {
                val arr = action.payload?.get("backups")?.jsonArray ?: return s
                val entries = arr.map { el ->
                    val obj = el.jsonObject
                    BackupEntry(
                        filename = obj["filename"]?.jsonPrimitive?.content ?: "",
                        sizeBytes = obj["sizeBytes"]?.jsonPrimitive?.longOrNull ?: 0L,
                        createdAt = obj["createdAt"]?.jsonPrimitive?.longOrNull ?: 0L
                    )
                }
                s.copy(backups = entries)
            }

            ActionRegistry.Names.BACKUP_CREATE -> s.copy(isCreating = true)

            ActionRegistry.Names.BACKUP_RESTORE -> {
                val fn = action.payload?.get("filename")?.jsonPrimitive?.content ?: return s
                s.copy(pendingRestoreFilename = fn)
            }

            ActionRegistry.Names.BACKUP_EXECUTE_RESTORE -> s.copy(isRestoring = true)

            ActionRegistry.Names.BACKUP_OPERATION_RESULT -> {
                val msg = action.payload?.get("message")?.jsonPrimitive?.content
                s.copy(isCreating = false, isRestoring = false,
                    pendingRestoreFilename = null, lastResultMessage = msg)
            }

            ActionRegistry.Names.SETTINGS_VALUE_CHANGED -> {
                val key = action.payload?.get("key")?.jsonPrimitive?.content ?: return s
                val value = action.payload?.get("value")?.jsonPrimitive?.content ?: return s
                when (key) {
                    "backup.autoBackupEnabled" -> s.copy(
                        autoBackupEnabled = value.toBooleanStrictOrNull() ?: true)
                    "backup.maxBackups" -> s.copy(
                        maxBackups = value.toIntOrNull() ?: 20)
                    else -> s
                }
            }

            ActionRegistry.Names.SETTINGS_LOADED -> {
                val p = action.payload ?: return s
                s.copy(
                    autoBackupEnabled = p["backup.autoBackupEnabled"]
                        ?.jsonPrimitive?.content?.toBooleanStrictOrNull() ?: s.autoBackupEnabled,
                    maxBackups = p["backup.maxBackups"]
                        ?.jsonPrimitive?.content?.toIntOrNull() ?: s.maxBackups
                )
            }

            else -> s
        }
    }

    // Side effects continued in 06b-BackupFeature-SideEffects.kt
    // (Split for readability — in actual codebase this is one file)
