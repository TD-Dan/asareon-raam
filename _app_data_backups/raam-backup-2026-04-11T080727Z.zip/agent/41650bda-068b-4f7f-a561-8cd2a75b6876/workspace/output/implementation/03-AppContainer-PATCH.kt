// ============================================================================
// PATCH: AppContainer.kt
// Add BackupFeature import and instance to the features list.
// BackupFeature should be FIRST in the list to ensure its preInit() runs
// before any other feature's preInit(), though the contract states all
// preInit() work should be non-mutating, so order should not matter.
// ============================================================================

// ADD IMPORT:
import asareon.raam.feature.backup.BackupFeature

// REPLACE the features list construction with:
    val features: List<Feature> = run {
        val gatewayFeature = GatewayFeature(
            platformDependencies,
            resilientCoroutineScope,
            providers = listOf(
                GeminiProvider(platformDependencies),
                OpenAIProvider(platformDependencies),
                AnthropicProvider(platformDependencies),
                InceptionProvider(platformDependencies)
            )
        )

        val allFeatures = mutableListOf<Feature>()
        allFeatures.addAll(listOf(
            BackupFeature(platformDependencies),       // L1: Must run preInit() early
            CoreFeature(platformDependencies),
            SettingsFeature(platformDependencies),
            FileSystemFeature(platformDependencies),
            SessionFeature(platformDependencies, resilientCoroutineScope),
            gatewayFeature,
            AgentRuntimeFeature(platformDependencies, resilientCoroutineScope),
            KnowledgeGraphFeature(platformDependencies, resilientCoroutineScope),
            CommandBotFeature(platformDependencies)
        ))
        allFeatures
    }
