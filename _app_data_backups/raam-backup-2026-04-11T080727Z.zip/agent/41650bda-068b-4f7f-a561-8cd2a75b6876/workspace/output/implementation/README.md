# BackupFeature Implementation Files

Ordered list of changes needed to integrate the BackupFeature.

## New Files (create in codebase)

| File | Target Location | Description |
|------|----------------|-------------|
| `04-backup.actions.json` | `feature/backup/backup.actions.json` | Action schema (9 actions). Must be included in ActionRegistry code generation. |
| `05-BackupState.kt` | `feature/backup/BackupState.kt` | Data classes: BackupState, BackupEntry |
| `06a + 06b` | `feature/backup/BackupFeature.kt` | Split into two files for delivery (output size limit). Combine into single file in codebase. 06a has class decl + preInit + reducer. 06b has handleSideEffects + helpers + closing brace. |

## Modified Files (patch existing)

| File | Target | Description |
|------|--------|-------------|
| `01-Feature.kt` | `core/Feature.kt` | FULL REPLACEMENT. Adds `preInit()` with KDoc contract. |
| `02-Store-PATCH.kt` | `core/Store.kt` | Replace ONLY `initFeatureLifecycles()`. Adds `features.forEach { it.preInit() }` before init. |
| `03-AppContainer-PATCH.kt` | `core/AppContainer.kt` | Add BackupFeature import + instance to features list. |
| `07-PlatformDependencies-PATCH.kt` | `util/PlatformDependencies.kt` | SIGNATURE CHANGE: `createZipArchive` gets `excludeDirectoryName` param. NEW: `extractZipArchive`, `fileSize`, `restartApplication`. These are `expect` declarations. |
| `08-PlatformDependencies-jvm-PATCH.kt` | `util/PlatformDependencies.jvm.kt` | `actual` implementations for JVM. Includes zip-slip protection in extractZipArchive. |

## ActionRegistry Integration

The `backup.actions.json` file must be picked up by the ActionRegistry code generator so that `ActionRegistry.Names.BACKUP_CREATE` etc. are available at compile time.

## Platform Stubs Still Needed

- iOS, Android, WASM: Add `actual` stubs for the 4 new/changed PlatformDependencies methods.
- `extractZipArchive` and `restartApplication` can initially be no-ops or throw UnsupportedOperationException on non-JVM.

## Notes

- 06a incorrectly includes `import java.io.File` — REMOVE this import. The feature is commonMain and only uses platformDependencies methods.
- The split between 06a and 06b is purely for delivery. In the codebase, combine them into a single `BackupFeature.kt` file.
