    // ========================================================================
    // SIDE EFFECTS (continuation of BackupFeature class)
    // ========================================================================

    override fun handleSideEffects(
        action: Action, store: Store,
        previousState: FeatureState?, newState: FeatureState?
    ) {
        val state = newState as? BackupState ?: return

        when (action.name) {
            ActionRegistry.Names.SYSTEM_INITIALIZING -> {
                registerSettings(store)
                scanAndDispatchInventory(store)
            }

            ActionRegistry.Names.SETTINGS_VALUE_CHANGED -> {
                val key = action.payload?.get("key")?.jsonPrimitive?.content
                if (key == "backup.autoBackupEnabled" || key == "backup.maxBackups") {
                    writeHintFile(state)
                    if (key == "backup.maxBackups") pruneBackups(store, state)
                }
            }

            ActionRegistry.Names.SETTINGS_LOADED -> {
                writeHintFile(state)
                pruneBackups(store, state)
            }

            ActionRegistry.Names.BACKUP_CREATE -> {
                val label = action.payload?.get("label")?.jsonPrimitive?.content
                performCreateBackup(store, state, label)
            }

            ActionRegistry.Names.BACKUP_RESTORE -> {
                val filename = action.payload?.get("filename")?.jsonPrimitive?.content ?: return
                store.deferredDispatch(identity.handle, Action(
                    name = ActionRegistry.Names.CORE_SHOW_CONFIRMATION_DIALOG,
                    payload = buildJsonObject {
                        put("title", "Restore Backup")
                        put("message", "Restore from '$filename'? This replaces ALL current data. A safety backup will be created first.")
                        put("confirmActionName", ActionRegistry.Names.BACKUP_EXECUTE_RESTORE)
                        put("confirmActionPayload", buildJsonObject { put("filename", filename) })
                    }
                ))
            }

            ActionRegistry.Names.BACKUP_EXECUTE_RESTORE -> {
                val filename = action.payload?.get("filename")?.jsonPrimitive?.content ?: return
                performRestore(store, filename)
            }

            ActionRegistry.Names.BACKUP_DELETE -> {
                val filename = action.payload?.get("filename")?.jsonPrimitive?.content ?: return
                performDelete(store, filename)
            }

            ActionRegistry.Names.BACKUP_PRUNE -> pruneBackups(store, state)

            ActionRegistry.Names.BACKUP_OPEN_FOLDER -> {
                platformDependencies.openFolderInExplorer(backupsDir)
            }

            ActionRegistry.Names.BACKUP_REFRESH -> scanAndDispatchInventory(store)
        }
    }

    // ========================================================================
    // PRIVATE HELPERS
    // ========================================================================

    private fun registerSettings(store: Store) {
        store.deferredDispatch(identity.handle, Action(
            name = ActionRegistry.Names.SETTINGS_ADD,
            payload = buildJsonObject {
                put("key", "backup.autoBackupEnabled")
                put("type", "BOOLEAN")
                put("label", "Auto-backup on startup")
                put("description", "Automatically create a backup snapshot each time the application starts.")
                put("section", "Backup")
                put("defaultValue", "true")
            }
        ))
        store.deferredDispatch(identity.handle, Action(
            name = ActionRegistry.Names.SETTINGS_ADD,
            payload = buildJsonObject {
                put("key", "backup.maxBackups")
                put("type", "NUMERIC_LONG")
                put("label", "Maximum backups to retain")
                put("description", "Oldest backups are pruned automatically when this limit is exceeded.")
                put("section", "Backup")
                put("defaultValue", "20")
            }
        ))
    }

    private fun writeHintFile(state: BackupState) {
        try {
            val json = buildJsonObject {
                put("autoBackupEnabled", state.autoBackupEnabled)
                put("maxBackups", state.maxBackups)
            }
            platformDependencies.writeFileContent(configFilePath, json.toString())
        } catch (e: Exception) {
            platformDependencies.log(LogLevel.WARN, tag, "Failed to write .backup-config hint file.", e)
        }
    }

    private fun scanAndDispatchInventory(store: Store) {
        try {
            if (!platformDependencies.fileExists(backupsDir)) return
            val entries = platformDependencies.listDirectory(backupsDir)
                .filter { !it.isDirectory && it.path.endsWith(".zip") }
                .map { entry ->
                    BackupEntry(
                        filename = platformDependencies.getFileName(entry.path),
                        sizeBytes = platformDependencies.fileSize(entry.path),
                        createdAt = entry.lastModified ?: 0L
                    )
                }
                .sortedByDescending { it.createdAt }

            val backupsArray = buildJsonArray {
                entries.forEach { e ->
                    add(buildJsonObject {
                        put("filename", e.filename)
                        put("sizeBytes", e.sizeBytes)
                        put("createdAt", e.createdAt)
                    })
                }
            }
            store.deferredDispatch(identity.handle, Action(
                name = ActionRegistry.Names.BACKUP_INVENTORY_UPDATED,
                payload = buildJsonObject { put("backups", backupsArray) }
            ))
        } catch (e: Exception) {
            platformDependencies.log(LogLevel.ERROR, tag, "Failed to scan backup directory.", e)
        }
    }

    private fun performCreateBackup(store: Store, state: BackupState, label: String?) {
        try {
            val timestamp = platformDependencies
                .formatIsoTimestamp(platformDependencies.currentTimeMillis())
                .replace(":", "")
            val suffix = if (label != null) "-$label" else ""
            val filename = "raam-backup-$timestamp$suffix.zip"
            val path = "$backupsDir$sep$filename"

            platformDependencies.createZipArchive(
                sourceDirectoryPath = appZonePath,
                destinationZipPath = path,
                excludeDirectoryName = "_backups"
            )
            dispatchResult(store, "create", true, "Backup created: $filename")
            scanAndDispatchInventory(store)
            pruneBackups(store, state)
        } catch (e: Exception) {
            platformDependencies.log(LogLevel.ERROR, tag, "Failed to create manual backup.", e)
            dispatchResult(store, "create", false, "Backup creation failed: ${e.message}")
        }
    }

    private fun performRestore(store: Store, filename: String) {
        try {
            val backupPath = "$backupsDir$sep$filename"
            if (!platformDependencies.fileExists(backupPath)) {
                dispatchResult(store, "restore", false, "Backup file not found: $filename")
                return
            }

            // 1. Safety backup before restore
            val safetyTimestamp = platformDependencies
                .formatIsoTimestamp(platformDependencies.currentTimeMillis())
                .replace(":", "")
            val safetyFilename = "raam-backup-pre-restore-$safetyTimestamp.zip"
            val safetyPath = "$backupsDir$sep$safetyFilename"
            platformDependencies.createZipArchive(
                sourceDirectoryPath = appZonePath,
                destinationZipPath = safetyPath,
                excludeDirectoryName = "_backups"
            )
            platformDependencies.log(LogLevel.INFO, tag, "Safety backup created: $safetyFilename")

            // 2. Write skip marker so next startup skips backup
            platformDependencies.writeFileContent(skipMarkerPath, "skip")

            // 3. Delete all APP_ZONE content EXCEPT _backups
            platformDependencies.listDirectory(appZonePath)
                .filter { platformDependencies.getFileName(it.path) != "_backups" }
                .forEach { entry ->
                    if (entry.isDirectory) {
                        platformDependencies.deleteDirectory(entry.path)
                    } else {
                        platformDependencies.deleteFile(entry.path)
                    }
                }

            // 4. Extract backup over APP_ZONE
            platformDependencies.extractZipArchive(
                zipPath = backupPath,
                targetDirectoryPath = appZonePath
            )
            platformDependencies.log(LogLevel.INFO, tag, "Restore complete. Restarting application.")

            // 5. Restart application
            platformDependencies.restartApplication()

        } catch (e: Exception) {
            platformDependencies.log(LogLevel.ERROR, tag, "Restore failed.", e)
            dispatchResult(store, "restore", false, "Restore failed: ${e.message}")
        }
    }

    private fun performDelete(store: Store, filename: String) {
        try {
            val path = "$backupsDir$sep$filename"
            if (platformDependencies.fileExists(path)) {
                platformDependencies.deleteFile(path)
                dispatchResult(store, "delete", true, "Deleted: $filename")
                scanAndDispatchInventory(store)
            } else {
                dispatchResult(store, "delete", false, "File not found: $filename")
            }
        } catch (e: Exception) {
            platformDependencies.log(LogLevel.ERROR, tag, "Failed to delete backup.", e)
            dispatchResult(store, "delete", false, "Delete failed: ${e.message}")
        }
    }

    private fun pruneBackups(store: Store, state: BackupState) {
        try {
            if (!platformDependencies.fileExists(backupsDir)) return
            val zips = platformDependencies.listDirectory(backupsDir)
                .filter { !it.isDirectory && it.path.endsWith(".zip") }
                .sortedByDescending { it.lastModified ?: 0L }

            if (zips.size > state.maxBackups) {
                val toDelete = zips.drop(state.maxBackups)
                toDelete.forEach { entry ->
                    platformDependencies.deleteFile(entry.path)
                    platformDependencies.log(LogLevel.INFO, tag,
                        "Pruned old backup: ${platformDependencies.getFileName(entry.path)}")
                }
                scanAndDispatchInventory(store)
            }
        } catch (e: Exception) {
            platformDependencies.log(LogLevel.ERROR, tag, "Pruning failed.", e)
        }
    }

    private fun dispatchResult(store: Store, operation: String, success: Boolean, message: String) {
        store.deferredDispatch(identity.handle, Action(
            name = ActionRegistry.Names.BACKUP_OPERATION_RESULT,
            payload = buildJsonObject {
                put("operation", operation)
                put("success", success)
                put("message", message)
            }
        ))
    }
} // end BackupFeature
