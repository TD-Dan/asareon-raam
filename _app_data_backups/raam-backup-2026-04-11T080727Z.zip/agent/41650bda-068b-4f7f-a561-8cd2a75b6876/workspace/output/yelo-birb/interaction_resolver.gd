## InteractionResolver — Physics-Driven Contact Resolution System
## Attach to any entity that has InteractionSurface Area2D children.
##
## Architecture: Physics colliders handle WHEN collisions happen.
## Area2D InteractionSurfaces handle WHAT KIND of interaction applies.
##
## Each physics frame (after move_and_slide), we check slide collisions
## to find entities we physically touched, then query overlapping Area2D
## zones to classify the interaction surfaces involved.
##
## Velocity changes:
## - Bounce uses entity.set_velocity_override() — a direct velocity replacement
##   that takes effect at the START of the entity's next _physics_process.
##   This avoids the time-frame mismatch where move_and_slide has already
##   altered velocity before we compute the delta.
## - Knockback uses entity.add_impulse() — an additive force.
## Both are applied before gravity/input/move_and_slide.
class_name InteractionResolver
extends Node


## Base knockback force in pixels/second. Multiplied by the surface's knockback value.
@export var knockback_base_force: float = 200.0

## Enable/disable debug prints for interaction events.
@export var debug_print: bool = true


## Track which entities have been resolved this physics frame to prevent
## double-resolution from multiple slide collisions with the same entity.
var _resolved_this_frame: Dictionary = {}  # entity_instance_id -> true

## Track which entity pairs have been resolved during sustained contact.
## Key: entity_instance_id. Cleared when physics collision with that entity stops.
var _resolved_contacts: Dictionary = {}  # entity_instance_id -> true

## Set of entities we had physics collision with last frame.
## Used to detect when collisions end (to clear _resolved_contacts).
var _colliding_last_frame: Dictionary = {}  # entity_instance_id -> true

## Our entity's InteractionSurface children, cached on ready.
var _surfaces: Array[InteractionSurface] = []

## Reference to our parent entity (the CharacterBody2D we're attached to).
var _entity: CharacterBody2D = null


func _ready() -> void:
	_entity = get_parent() as CharacterBody2D
	if _entity == null:
		push_error("[InteractionResolver] Parent must be a CharacterBody2D")
		return
	
	# Cache all InteractionSurface children of our parent entity
	for child in _entity.get_children():
		if child is InteractionSurface:
			_surfaces.append(child)
	
	if debug_print:
		print("[InteractionResolver] %s: Ready with %d surfaces" % [_entity.name, _surfaces.size()])


func _physics_process(_delta: float) -> void:
	if _entity == null:
		return
	
	_resolved_this_frame.clear()
	var colliding_this_frame: Dictionary = {}
	
	# Check all physics (slide) collisions from this frame's move_and_slide()
	for i in range(_entity.get_slide_collision_count()):
		var collision: KinematicCollision2D = _entity.get_slide_collision(i)
		var collider: Object = collision.get_collider()
		
		# We only resolve against other entities that have InteractionSurfaces
		if not collider is CharacterBody2D:
			continue
		
		var their_entity: CharacterBody2D = collider as CharacterBody2D
		var their_id: int = their_entity.get_instance_id()
		
		colliding_this_frame[their_id] = true
		
		# Don't re-resolve same entity multiple times per frame
		if _resolved_this_frame.has(their_id):
			continue
		
		# Don't re-resolve sustained contact (until contact breaks)
		if _resolved_contacts.has(their_id):
			continue
		
		# Find which of our surfaces overlap which of their surfaces
		var overlapping_pairs: Array = _find_overlapping_surface_pairs(their_entity)
		
		if overlapping_pairs.is_empty():
			if debug_print:
				print("[InteractionResolver] %s: Physics collision with %s but no overlapping surfaces" % [
					_entity.name, their_entity.name
				])
			continue
		
		# Pick the closest surface pair by distance_squared between centers
		var best_pair = null
		var best_dist_sq: float = INF
		
		for pair in overlapping_pairs:
			var dist_sq: float = pair["my_surface"].global_position.distance_squared_to(
					pair["their_surface"].global_position)
			if dist_sq < best_dist_sq:
				best_dist_sq = dist_sq
				best_pair = pair
		
		if best_pair == null:
			continue
		
		if debug_print and overlapping_pairs.size() > 1:
			print("[InteractionResolver] %s: %d overlapping surface pairs with %s — resolved by proximity (dist²=%.1f)" % [
				_entity.name,
				overlapping_pairs.size(),
				their_entity.name,
				best_dist_sq
			])
		
		# Get pre-collision velocity for bounce calculations
		var my_pre_velocity: Vector2 = _get_pre_collision_velocity(_entity)
		var their_pre_velocity: Vector2 = _get_pre_collision_velocity(their_entity)
		
		# Resolve!
		_resolve_contact(
			_entity, best_pair["my_surface"], my_pre_velocity,
			their_entity, best_pair["their_surface"], their_pre_velocity
		)
		
		_resolved_this_frame[their_id] = true
		_resolved_contacts[their_id] = true
	
	# Clear resolved_contacts for entities we're no longer physically colliding with
	for entity_id in _colliding_last_frame:
		if not colliding_this_frame.has(entity_id):
			if _resolved_contacts.has(entity_id):
				if debug_print:
					print("[InteractionResolver] %s: Physics contact ended with entity %d (cleared for re-trigger)" % [
						_entity.name, entity_id
					])
				_resolved_contacts.erase(entity_id)
	
	_colliding_last_frame = colliding_this_frame


## Find all pairs of (my_surface, their_surface) that are currently overlapping.
## Uses Area2D.get_overlapping_areas() on each of our surfaces.
func _find_overlapping_surface_pairs(their_entity: CharacterBody2D) -> Array:
	var pairs: Array = []
	
	for my_surface in _surfaces:
		var overlapping: Array[Area2D] = my_surface.get_overlapping_areas()
		for area in overlapping:
			if area is InteractionSurface:
				var their_surface: InteractionSurface = area as InteractionSurface
				if their_surface.get_owner_entity() == their_entity:
					pairs.append({
						"my_surface": my_surface,
						"their_surface": their_surface
					})
	
	return pairs


## Get the pre-collision velocity from an entity.
## Entities should implement get_pre_collision_velocity() for accurate bounce.
func _get_pre_collision_velocity(entity: CharacterBody2D) -> Vector2:
	if entity.has_method("get_pre_collision_velocity"):
		return entity.get_pre_collision_velocity()
	# Fallback: use current velocity (may be zeroed by move_and_slide)
	return entity.velocity


## The core resolution pipeline: Bounce → Damage → Knockback
## Bounce uses set_velocity_override (direct replacement).
## Knockback uses add_impulse (additive force).
## Bounce dampening: if entity implements is_dampening_bounce() and returns true,
## the reflected velocity is multiplied by the entity's bounce_dampen_multiplier.
func _resolve_contact(
		my_entity: CharacterBody2D, my_surface: InteractionSurface, my_pre_velocity: Vector2,
		their_entity: CharacterBody2D, their_surface: InteractionSurface, their_pre_velocity: Vector2) -> void:
	
	if debug_print:
		print("[InteractionResolver] %s: === RESOLVING ===" % _entity.name)
		print("  My %s: dmg=%d shld=%d bounce=%.1f kb=%.1f" % [
			my_surface.name,
			my_surface.damage_value, my_surface.shield_value,
			my_surface.bounciness, my_surface.knockback
		])
		print("  Their %s (%s): dmg=%d shld=%d bounce=%.1f kb=%.1f" % [
			their_surface.name, their_entity.name,
			their_surface.damage_value, their_surface.shield_value,
			their_surface.bounciness, their_surface.knockback
		])
	
	# === Step 1: Bounce (velocity override — not a delta) ===
	# Bounce reflects the PRE-COLLISION velocity off the surface normal.
	# We set the entity's velocity directly to the reflected vector using
	# set_velocity_override(), avoiding the time-frame mismatch bug where
	# move_and_slide has already altered entity.velocity.
	# Skip bounce if pre-velocity is near zero — nothing meaningful to reflect.
	# Dampening: if the entity being bounced holds Down, reduce bounce energy.
	if my_surface.is_bouncy():
		var reflected := _compute_bounce_target(my_surface, their_pre_velocity)
		if their_pre_velocity.length_squared() > 1.0:
			# Check if the entity being bounced wants to dampen
			if their_entity.has_method("is_dampening_bounce") and their_entity.is_dampening_bounce():
				reflected *= their_entity.get("bounce_dampen_multiplier") if their_entity.get("bounce_dampen_multiplier") != null else 0.5
				if debug_print:
					print("  → Bounce %s: %s DAMPENED pre-velocity %s → reflected %s (×%.1f)" % [
						their_entity.name, my_surface.name,
						their_pre_velocity, reflected, my_surface.bounciness
					])
			else:
				if debug_print:
					print("  → Bounce %s: %s pre-velocity %s → reflected %s (×%.1f)" % [
						their_entity.name, my_surface.name,
						their_pre_velocity, reflected, my_surface.bounciness
					])
			_set_velocity_override_on(their_entity, reflected)
		elif debug_print:
			print("  → Bounce %s: SKIPPED (pre-velocity near zero: %s)" % [
				their_entity.name, their_pre_velocity
			])
	
	if their_surface.is_bouncy():
		var reflected := _compute_bounce_target(their_surface, my_pre_velocity)
		if my_pre_velocity.length_squared() > 1.0:
			# Check if the entity being bounced wants to dampen
			if my_entity.has_method("is_dampening_bounce") and my_entity.is_dampening_bounce():
				reflected *= my_entity.get("bounce_dampen_multiplier") if my_entity.get("bounce_dampen_multiplier") != null else 0.5
				if debug_print:
					print("  → Bounce %s: %s DAMPENED pre-velocity %s → reflected %s (×%.1f)" % [
						my_entity.name, their_surface.name,
						my_pre_velocity, reflected, their_surface.bounciness
					])
			else:
				if debug_print:
					print("  → Bounce %s: %s pre-velocity %s → reflected %s (×%.1f)" % [
						my_entity.name, their_surface.name,
						my_pre_velocity, reflected, their_surface.bounciness
					])
			_set_velocity_override_on(my_entity, reflected)
		elif debug_print:
			print("  → Bounce %s: SKIPPED (pre-velocity near zero: %s)" % [
				my_entity.name, my_pre_velocity
			])
	
	# === Step 2: Damage (both directions) ===
	var dmg_to_them: int = maxi(0, my_surface.damage_value - their_surface.shield_value)
	var dmg_to_me: int = maxi(0, their_surface.damage_value - my_surface.shield_value)
	
	if dmg_to_them > 0 and their_entity.has_method("take_damage"):
		if debug_print:
			print("  → Damage to %s: %d (attack %d - shield %d)" % [
				their_entity.name, dmg_to_them,
				my_surface.damage_value, their_surface.shield_value
			])
		their_entity.take_damage(dmg_to_them)
	elif debug_print and my_surface.damage_value > 0:
		print("  → Damage to %s BLOCKED (attack %d - shield %d = 0)" % [
			their_entity.name, my_surface.damage_value, their_surface.shield_value
		])
	
	if dmg_to_me > 0 and my_entity.has_method("take_damage"):
		if debug_print:
			print("  → Damage to %s: %d (attack %d - shield %d)" % [
				my_entity.name, dmg_to_me,
				their_surface.damage_value, my_surface.shield_value
			])
		my_entity.take_damage(dmg_to_me)
	elif debug_print and their_surface.damage_value > 0:
		print("  → Damage to %s BLOCKED (attack %d - shield %d = 0)" % [
			my_entity.name, their_surface.damage_value, my_surface.shield_value
		])
	
	# === Step 3: Knockback (applied when attacker has damage, even if shielded) ===
	if my_surface.damage_value > 0 and my_surface.knockback > 0.0:
		var kb_factor := _calculate_knockback_factor(my_surface.damage_value, their_surface.shield_value)
		var kb_impulse := my_surface.get_contact_normal() * knockback_base_force * my_surface.knockback * kb_factor
		if debug_print:
			print("  → Knockback to %s: dir=%s base=%.0f ×mult=%.1f ×factor=%.2f = %s" % [
				their_entity.name,
				my_surface.get_contact_normal(),
				knockback_base_force,
				my_surface.knockback,
				kb_factor,
				kb_impulse
			])
		_add_impulse_to(their_entity, kb_impulse)
	
	if their_surface.damage_value > 0 and their_surface.knockback > 0.0:
		var kb_factor := _calculate_knockback_factor(their_surface.damage_value, my_surface.shield_value)
		var kb_impulse := their_surface.get_contact_normal() * knockback_base_force * their_surface.knockback * kb_factor
		if debug_print:
			print("  → Knockback to %s: dir=%s base=%.0f ×mult=%.1f ×factor=%.2f = %s" % [
				my_entity.name,
				their_surface.get_contact_normal(),
				knockback_base_force,
				their_surface.knockback,
				kb_factor,
				kb_impulse
			])
		_add_impulse_to(my_entity, kb_impulse)
	
	if debug_print:
		print("[InteractionResolver] %s: === RESOLVED ===" % _entity.name)


## Compute the bounce target velocity (not a delta — the actual velocity the entity should have).
## Reflects pre_velocity off the surface normal and scales by bounciness.
func _compute_bounce_target(bounce_surface: InteractionSurface, pre_velocity: Vector2) -> Vector2:
	var normal := bounce_surface.get_contact_normal()
	return pre_velocity.bounce(normal) * bounce_surface.bounciness


## Safely set a velocity override on an entity. The entity must have set_velocity_override().
## Falls back to direct velocity assignment if not available (with a warning).
func _set_velocity_override_on(entity: CharacterBody2D, new_velocity: Vector2) -> void:
	if entity.has_method("set_velocity_override"):
		entity.set_velocity_override(new_velocity)
	else:
		push_warning("[InteractionResolver] %s has no set_velocity_override() — setting velocity directly" % entity.name)
		entity.velocity = new_velocity


## Safely add an impulse to an entity. The entity must have an add_impulse() method.
## Falls back to direct velocity modification if not available (with a warning).
func _add_impulse_to(entity: CharacterBody2D, impulse: Vector2) -> void:
	if entity.has_method("add_impulse"):
		entity.add_impulse(impulse)
	else:
		push_warning("[InteractionResolver] %s has no add_impulse() — applying directly to velocity" % entity.name)
		entity.velocity += impulse


## Calculate knockback reduction from shields.
## Returns a factor from 0.25 (heavily shielded) to 1.0 (no shield).
func _calculate_knockback_factor(damage: int, shield: int) -> float:
	if shield <= 0 or damage <= 0:
		return 1.0
	var absorption: float = float(shield) / float(damage)
	return clampf(1.0 - absorption * 0.75, 0.25, 1.0)
