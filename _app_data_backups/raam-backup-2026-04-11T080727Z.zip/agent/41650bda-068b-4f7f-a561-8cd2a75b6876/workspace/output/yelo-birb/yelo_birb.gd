extends CharacterBody2D

## Maximum speed attainable with inputs
@export var max_speed = 250.0

## Adjust jump power over time according to how long player holds down the jump button
@export var jump_power_stages = [-100, -75, -120]
## How long till applying next jump stage power impulse
@export var jump_power_stage_seconds = [0.0, 0.075, 0.15]

@export var acceleration = 1000
@export var walk_speed_multiplier = 0.5
@export var sneak_speed_multiplier = 0.1
@export var air_acceleration_multiplier = 2.0

# Delay switching from ground. Allows late jumps to avoid player frustration, aka. Coyote time
@export var coyote_time_seconds = 0.15

## How long to wait before entering Sitting idle state
@export var sitting_idle_threshold_s = 2.0

## Minimum animation speed_scale to prevent frozen-looking feet at very low speeds
@export var min_animation_speed_scale = 0.15

## Rotation speed in radians/second. At 4π (~720°/s), a 90° turn takes ~0.125s.
@export var air_rotation_speed: float = 4.0 * PI

## Minimum time between 90° rotation increments in seconds. Prevents strike-kit abuse.
## Also controls continuous rotation rate when held: one 90° turn per this interval.
@export var air_rotation_tap_cooldown: float = 0.1

## Multiplier applied to bounce velocity when player is holding Down.
## 0.5 = half bounce energy. Allows player to stop bouncing by dampening.
@export var bounce_dampen_multiplier: float = 0.5


@onready var birb_sprite = %Sprite

## Switches between different movement modes: Air, Ground, Water, Sitting
@onready var movemode_state = %MoveModeState

## Switches between different input speeds: Sneak (L/R with Sneak button pressed), Walk (L/R), Run (L/R with Run button pressed)
@onready var speed_state = %SpeedState

## Switches between lateral input speed options: Idle (no lateral movement), Move (active movement applied), Brake (active deceleration applied), Slide (active slide applied)
@onready var active_lateral_state = %ActiveLateralState

## Switches between vertical input movement: Idle (no vertical movement), Jump (Jump button pressed and jump is active), Up (up movement active), Down (down movement active)
@onready var active_vertical_state = %ActiveVerticalState


# Use the pixel snapped sprite as the real follow target. PlayerCamera will autodetect this variable
@onready var follow_anchor = %Sprite

# amount of user input on L/R axis
var lateral_input = 0.0

# tracking active jump
var current_jump_stage = 0
var time_from_jump_s = 0.0

# track time on and off floor
var time_on_floor_s = 0.0
var time_off_floor_s = 0.0

# idle time calculation
var time_idle_s = 0.0



## Velocity captured before move_and_slide(). Used by InteractionResolver for
## accurate bounce reflection (move_and_slide zeroes velocity on contact).
var _previous_velocity: Vector2 = Vector2.ZERO

## Pending impulse accumulator. Any system (resolver knockback, tiles, powerups)
## calls add_impulse() to sum into this vector. Drained at the START of
## _physics_process before gravity/input/move_and_slide, so impulses survive the frame.
var _pending_impulse: Vector2 = Vector2.ZERO

## Velocity override for bounce. Unlike add_impulse (which is additive), this
## REPLACES the entity's velocity entirely. Applied at the START of _physics_process
## BEFORE impulse drain, so bounce takes priority and knockback stacks on top.
var _pending_velocity_override: Vector2 = Vector2.ZERO
var _has_velocity_override: bool = false

## Target rotation in radians. Kept normalized to [-PI, PI] to match Godot's rotation range.
var _rotation_target: float = 0.0

## Cooldown timer for rotation increments (both tap and held).
var _rotation_cooldown: float = 0.0

## Bounce-jump window: time remaining during which a bounce grants jump permission.
## Set when an upward bounce fires (via set_velocity_override with negative y).
## Works like coyote time — player can press jump during this window to combo.
var _bounce_jump_window: float = 0.0


func _ready() -> void:
	movemode_state.set_state("Air")
	speed_state.set_state("Run")
	active_lateral_state.set_state("Idle")
	active_vertical_state.set_state("Idle")


func _physics_process(delta: float) -> void:
	
	# VELOCITY OVERRIDE — applied first. Bounce sets exact target velocity.
	if _has_velocity_override:
		velocity = _pending_velocity_override
		_has_velocity_override = false
		_pending_velocity_override = Vector2.ZERO
	
	# DRAIN IMPULSE — applied after override so knockback stacks on top of bounce.
	if _pending_impulse != Vector2.ZERO:
		velocity += _pending_impulse
		_pending_impulse = Vector2.ZERO
	
	# SPEED STATE (polled — works with analog stick)
	if Input.is_action_pressed("Down"):
		if not speed_state.is_state("Sneak"):
			speed_state.set_state("Sneak")
	elif Input.is_action_pressed("SecondaryAction"):
		if not speed_state.is_state("Walk"):
			speed_state.set_state("Walk")
	else:
		if not speed_state.is_state("Run"):
			speed_state.set_state("Run")
		
	# RAW TRACKING
	
	if is_on_floor():
		time_off_floor_s = 0.0
		time_on_floor_s += delta
	else:
		time_on_floor_s = 0.0
		time_off_floor_s += delta
	
	time_from_jump_s += delta
	
	# Tick bounce-jump window
	_bounce_jump_window = maxf(0.0, _bounce_jump_window - delta)
		
	lateral_input = Input.get_axis("Left", "Right")
	
	
	# DETECT STATE CHANGES
	
	if movemode_state.is_state("Air"):
		if time_on_floor_s > 0:
			movemode_state.set_state("Ground")
		elif not active_vertical_state.is_state("Jump"):
			if velocity.y < 0:
				active_vertical_state.set_state("Up")
			elif velocity.y > 0:
				active_vertical_state.set_state("Down")
			else:
				active_vertical_state.set_state("Idle")
	elif movemode_state.is_state("Ground") or movemode_state.is_state("Sitting"):
		if time_off_floor_s > coyote_time_seconds:
			movemode_state.set_state("Air")
	
	# Terminate active jump when all jump stages have been used
	if current_jump_stage > jump_power_stages.size():
		current_jump_stage = 0
		active_vertical_state.set_state("Up")
	
	# IDLE / SITTING TRACKING (ground only)
	if movemode_state.is_state("Ground") or movemode_state.is_state("Sitting"):
		if active_lateral_state.is_state("Idle") and active_vertical_state.is_state("Idle"):
			time_idle_s += delta
			if movemode_state.is_state("Ground") and time_idle_s >= sitting_idle_threshold_s:
				movemode_state.set_state("Sitting")
		else:
			time_idle_s = 0.0
			if movemode_state.is_state("Sitting"):
				movemode_state.set_state("Ground")
	else:
		time_idle_s = 0.0
	
	_set_lateral_state()
	
	# AIR ROTATION
	_process_air_rotation(delta)
	
	# APPLY FORCES
	
	# apply gravity
	if movemode_state.is_state("Air") and time_off_floor_s > coyote_time_seconds:
		velocity += get_gravity() * delta
	
	# Apply jump if active
	if active_vertical_state.is_state("Jump"):
		if time_from_jump_s >= jump_power_stage_seconds[current_jump_stage-1]:
			print("jump stage %s" % [current_jump_stage])
			velocity.y += jump_power_stages[current_jump_stage-1]
			current_jump_stage += 1
	
	# Apply input movement
	if active_lateral_state.is_state("Move"):
		var final_max_speed = max_speed
		if speed_state.is_state("Sneak"):
			final_max_speed *= sneak_speed_multiplier
		elif speed_state.is_state("Walk"):
			final_max_speed *= walk_speed_multiplier
		
		var final_acceleration = acceleration
		if time_off_floor_s > 0:
			final_acceleration *= air_acceleration_multiplier
		
		velocity.x = move_toward(velocity.x, lateral_input * final_max_speed, delta*final_acceleration)
	# Apply brake
	else:
		velocity.x = move_toward(velocity.x, 0, delta*acceleration)
	
	# COMMIT
	
	# keep velocity at sane levels
	velocity = velocity.limit_length(600)
	
	# Capture velocity BEFORE move_and_slide — this is the real incoming velocity.
	# InteractionResolver uses this via get_pre_collision_velocity() for accurate
	# bounce reflection, since move_and_slide() zeroes velocity on contact.
	_previous_velocity = velocity
	move_and_slide()
	
	
	# UPDATE VISUALS
	
	if velocity.x < 0:
		birb_sprite.scale.x = -1
	if velocity.x > 0:
		birb_sprite.scale.x = 1
	
	# Drive ground animation by actual velocity
	if (movemode_state.is_state("Ground") or movemode_state.is_state("Sitting")) and active_lateral_state.is_state("Move"):
		update_ground_animation()
	
	if movemode_state.is_state("Ground") and active_lateral_state.is_state("Move") and speed_state.is_state("Run"):
		%DustParticles.emit_dust()
	
	# Pixel snap the sprite to keep camera jitter and tearing free
	birb_sprite.global_position = round(global_position)
		
	return


## Queue a velocity impulse to be applied at the start of the next physics frame.
## All impulses are additive — multiple calls per frame are summed together.
## Used by InteractionResolver (knockback), tile bounces, powerups, etc.
func add_impulse(impulse: Vector2) -> void:
	_pending_impulse += impulse


## Set a velocity override to be applied at the start of the next physics frame.
## Unlike add_impulse, this REPLACES velocity entirely. Used for bounce reflection
## where the target velocity is known exactly.
## If called multiple times per frame, the last call wins.
## Also grants a bounce-jump window when the bounce is upward.
func set_velocity_override(new_velocity: Vector2) -> void:
	_pending_velocity_override = new_velocity
	_has_velocity_override = true
	# Grant a brief jump window when bouncing upward — like coyote time for bounces.
	# Player can press jump during this window to combo bounce + jump.
	if new_velocity.y < 0:
		_bounce_jump_window = coyote_time_seconds


## Returns the velocity captured before move_and_slide().
## Used by InteractionResolver for accurate bounce reflection.
func get_pre_collision_velocity() -> Vector2:
	return _previous_velocity


## Returns true if this entity wants to dampen its next bounce.
## Called by InteractionResolver to reduce bounce energy when player holds Down.
func is_dampening_bounce() -> bool:
	return Input.is_action_pressed("Down")


## Air rotation: 90° increments while airborne, snap to upright on ground.
## Holding the button continuously rotates (one 90° increment per cooldown interval).
## Tapping gives a single 90° increment with cooldown preventing double-fire.
##
## Key fix: Both _rotation_target and rotation are kept in [-PI, PI] range.
## We use angle_difference() to compute the shortest-path delta, avoiding the
## wrap-around bug where accumulated target values exceed Godot's rotation range.
func _process_air_rotation(delta: float) -> void:
	if movemode_state.is_state("Air"):
		# Tick cooldown
		_rotation_cooldown = maxf(0.0, _rotation_cooldown - delta)
		
		# Check for rotation input — both tap and held use the same cooldown gate.
		# is_action_pressed (not just_pressed) so holding keeps rotating.
		# The cooldown timer rate-limits to one 90° turn per interval.
		if _rotation_cooldown <= 0.0:
			if Input.is_action_pressed("RotateLeft"):
				_rotation_target = wrapf(_rotation_target - PI / 2.0, -PI, PI)
				_rotation_cooldown = air_rotation_tap_cooldown
			elif Input.is_action_pressed("RotateRight"):
				_rotation_target = wrapf(_rotation_target + PI / 2.0, -PI, PI)
				_rotation_cooldown = air_rotation_tap_cooldown
		
		# Rotate toward target using angle_difference for shortest path.
		# angle_difference(from, to) returns the signed shortest arc from 'from' to 'to'.
		var angle_diff := angle_difference(rotation, _rotation_target)
		if absf(angle_diff) < 0.001:
			rotation = _rotation_target
		else:
			rotation += signf(angle_diff) * minf(air_rotation_speed * delta, absf(angle_diff))
	else:
		# On ground: snap to upright (0°)
		_rotation_target = 0.0
		if absf(rotation) > 0.001:
			var angle_diff := angle_difference(rotation, 0.0)
			rotation += signf(angle_diff) * minf(air_rotation_speed * delta * 2.0, absf(angle_diff))
		else:
			rotation = 0.0
		_rotation_cooldown = 0.0


func take_damage(amount):
	%AnimationPlayer.play("damage_flash")



func _input(event: InputEvent) -> void:
	# Speed modifiers — default is Run
	if event.is_action_pressed("SecondaryAction"):
		speed_state.set_state("Walk")
	elif event.is_action_released("SecondaryAction"):
		if Input.is_action_pressed("Down"):
			speed_state.set_state("Sneak")
		else:
			speed_state.set_state("Run")
	# Jump
	elif event.is_action_pressed("PrimaryAction"):
		if can_jump():
			active_vertical_state.set_state("Jump")
	elif event.is_action_released("PrimaryAction"):
		active_vertical_state.set_state("Up")


func can_jump() -> bool:
	if time_from_jump_s < coyote_time_seconds*1.3:
		return false
	if movemode_state.is_state("Ground") or movemode_state.is_state("Sitting"):
		return true
	# Bounce grants a jump window — like coyote time but triggered by an upward bounce.
	# Player times their jump press to coincide with the bounce for a combo launch.
	if _bounce_jump_window > 0.0:
		return true
	return false


# Updates lateral state
func _set_lateral_state():
	if lateral_input:
		if (velocity.x > 0 and lateral_input < 0) or (velocity.x < 0 and lateral_input > 0):
			if movemode_state.is_state("Ground") or movemode_state.is_state("Sitting"):
				active_lateral_state.set_state("Brake")
		else:
			active_lateral_state.set_state("Move")
	else:
		if (movemode_state.is_state("Ground") or movemode_state.is_state("Sitting")) and (velocity.x > 0 or velocity.x < 0):
			active_lateral_state.set_state("Slide")
		else:
			active_lateral_state.set_state("Idle")


## Velocity-driven ground animation. Called every physics frame when on ground and moving.
## Selects animation tier based on actual speed and scales playback to match ground movement.
func update_ground_animation():
	var speed = abs(velocity.x)
	var walk_threshold = max_speed * walk_speed_multiplier + 1.0
	
	var anim_name: String
	var reference_speed: float
	
	# Sneak is a special case — driven by speed_state, not velocity tier
	if speed_state.is_state("Sneak"):
		anim_name = "sneak"
		reference_speed = max_speed * sneak_speed_multiplier
	elif speed <= walk_threshold:
		anim_name = "walk"
		reference_speed = max_speed * walk_speed_multiplier
	else:
		anim_name = "run"
		reference_speed = max_speed
	
	# Compute speed_scale: ratio of actual speed to the speed where this animation looks correct at 1x
	var scale_factor = speed / reference_speed if reference_speed > 0.0 else 1.0
	scale_factor = max(scale_factor, min_animation_speed_scale)
	
	if birb_sprite.animation != anim_name:
		birb_sprite.animation = anim_name
		birb_sprite.play()
	birb_sprite.speed_scale = scale_factor


## Event-driven ground animation for non-moving states (Brake, Slide, Idle).
## speed_scale is reset to 1.0 since these don't need velocity tracking.
func set_ground_animation():
	birb_sprite.speed_scale = 1.0
	if active_lateral_state.is_state("Brake"):
		%DustParticles.emit_dust()
		birb_sprite.animation = "brake"
		birb_sprite.play()
	elif active_lateral_state.is_state("Slide"):
		birb_sprite.animation = "brake"
		birb_sprite.play()
	elif active_lateral_state.is_state("Idle"):
		birb_sprite.animation = "idle"
		birb_sprite.play()
	elif active_lateral_state.is_state("Move"):
		# Move case now handled by update_ground_animation() each frame
		pass


func _on_move_mode_state_state_exiting(state: String) -> void:
	pass


func _on_move_mode_state_state_entered(state: String) -> void:
	if movemode_state.is_state("Ground") and movemode_state.previous_state_was("Air"):
		print("Hit the floor at velocity prev:%s current:%s" % [_previous_velocity, velocity])
		# Only zero vertical velocity if we're actually falling/stationary.
		# If velocity.y is negative (moving upward), a bounce is in progress — preserve it.
		if velocity.y >= 0:
			velocity.y = 0
		%DustParticles.emit_dust()
		set_ground_animation()
		active_vertical_state.set_state("Idle")
	if movemode_state.is_state("Air"):
		birb_sprite.speed_scale = 1.0
	if movemode_state.is_state("Sitting"):
		birb_sprite.speed_scale = 1.0
		birb_sprite.animation = "sitting"
		birb_sprite.play()


func _on_vertical_state_state_entered(state: String) -> void:
	if active_vertical_state.is_state("Jump"):
		# activate jump in _physics_process
		current_jump_stage = 1
		time_from_jump_s = 0.0
		# Consume bounce-jump window on use so it can't double-fire
		_bounce_jump_window = 0.0
		
		%DustParticles.emit_dust()
		
		birb_sprite.speed_scale = 1.0
		birb_sprite.animation = "air_up"
		birb_sprite.play()
	if movemode_state.is_state("Air"):
		birb_sprite.speed_scale = 1.0
		if active_vertical_state.is_state("Idle"):
			birb_sprite.animation = "air_idle"
			birb_sprite.play()
		elif active_vertical_state.is_state("Up"):
			birb_sprite.animation = "air_up"
			birb_sprite.play()
		elif active_vertical_state.is_state("Down"):
			birb_sprite.animation = "air_down"
			birb_sprite.play()


func _on_vertical_state_state_exiting(state: String) -> void:
	if active_vertical_state.is_state("Jump"):
		# terminate jump in _physics_process
		current_jump_stage = 0


func _on_active_lateral_state_state_entered(state: String) -> void:	
	if movemode_state.is_state("Ground"):
		set_ground_animation()


func _on_area_2d_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	print("colliding with %s %s" % [body, body_shape_index])
	var tilemap := body as TileMapLayer
	if tilemap:
		var coords := tilemap.get_coords_for_body_rid(body_rid)
		var tiledata := tilemap.get_cell_tile_data(coords)
		var bounce_from_tile = tiledata.get_custom_data("bounce")
		if bounce_from_tile > 0.0:
			# Tile bounce: reflect pre-collision velocity off the tile surface.
			# Use set_velocity_override for exact target — same pattern as entity bounce.
			var bounce_normal = Vector2.UP  # tiles bounce upward by default
			var reflected = _previous_velocity.bounce(bounce_normal) * bounce_from_tile
			if _previous_velocity.length_squared() > 1.0:
				# Dampen tile bounce if player is holding Down
				if is_dampening_bounce():
					reflected *= bounce_dampen_multiplier
				set_velocity_override(reflected)
				print("Tile bounce: override velocity to %s (reflected from %s)" % [reflected, _previous_velocity])
			else:
				print("Tile bounce: SKIPPED (velocity near zero)")
		var damage_from_tile = tiledata.get_custom_data("damage")
		if damage_from_tile > 0:
			self.take_damage(damage_from_tile)
		if tiledata.get_custom_data("dust"):
			%DustParticles.emitting = true
			%DustParticles.process_material.color = tiledata.get_custom_data("dust_color")


func _on_area_2d_area_shape_entered(area_rid: RID, area: Area2D, area_shape_index: int, local_shape_index: int) -> void:
	print("colliding with %s %s" % [area, area_shape_index])
