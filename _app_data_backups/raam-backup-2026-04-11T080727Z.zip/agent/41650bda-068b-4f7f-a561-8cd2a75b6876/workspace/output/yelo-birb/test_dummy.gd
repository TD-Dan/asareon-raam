## TestDummy — Configurable test target for interaction zone testing
## Place in a scene with 4 InteractionSurface Area2D children and an InteractionResolver.
## Each surface can be configured to a named preset via @export.
extends CharacterBody2D


## Maximum hit points. Damage animations map to remaining HP.
@export var max_hp: int = 3

## Auto-respawn delay in seconds after being broken. 0 = stays dead.
@export var respawn_delay: float = 1.0

@onready var sprite: AnimatedSprite2D = %Sprite
@onready var anim_player: AnimationPlayer = %AnimationPlayer
@onready var label: Label = %Label

## Current HP
var current_hp: int = 0

## Whether the dummy is currently broken (dead)
var is_broken: bool = false

## Timer for respawn countdown
var _respawn_timer: float = 0.0

## Cached surface references (populated in _ready)
var _surfaces: Dictionary = {}  # "top", "right", "bottom", "left" -> InteractionSurface

## Velocity captured before move_and_slide(). Used by InteractionResolver for
## accurate bounce reflection.
var _previous_velocity: Vector2 = Vector2.ZERO

## Pending impulse accumulator. Any system calls add_impulse() to sum into this
## vector. Drained at the START of _physics_process before gravity/move_and_slide.
var _pending_impulse: Vector2 = Vector2.ZERO

## Velocity override for bounce. Replaces velocity entirely when set.
## Applied before impulse drain so knockback stacks on top.
var _pending_velocity_override: Vector2 = Vector2.ZERO
var _has_velocity_override: bool = false


func _ready() -> void:
	_respawn()


func _physics_process(delta: float) -> void:
	# VELOCITY OVERRIDE — applied first. Bounce sets exact target velocity.
	if _has_velocity_override:
		velocity = _pending_velocity_override
		_has_velocity_override = false
		_pending_velocity_override = Vector2.ZERO
	
	# DRAIN IMPULSE — applied after override so knockback stacks on top of bounce.
	if _pending_impulse != Vector2.ZERO:
		velocity += _pending_impulse
		_pending_impulse = Vector2.ZERO
	
	# Gravity
	if not is_on_floor():
		velocity += get_gravity() * delta
	
	# Capture velocity before move_and_slide for bounce calculations
	_previous_velocity = velocity
	move_and_slide()
	
	# Respawn timer
	if is_broken and respawn_delay > 0.0:
		_respawn_timer -= delta
		if _respawn_timer <= 0.0:
			_respawn()
	
	# Update debug label
	_update_label()


## Queue a velocity impulse to be applied at the start of the next physics frame.
## All impulses are additive — multiple calls per frame are summed together.
func add_impulse(impulse: Vector2) -> void:
	_pending_impulse += impulse


## Set a velocity override to be applied at the start of the next physics frame.
## Unlike add_impulse, this REPLACES velocity entirely. Used for bounce reflection.
## If called multiple times per frame, the last call wins.
func set_velocity_override(new_velocity: Vector2) -> void:
	_pending_velocity_override = new_velocity
	_has_velocity_override = true


## Returns the velocity captured before move_and_slide().
## Used by InteractionResolver for accurate bounce reflection.
func get_pre_collision_velocity() -> Vector2:
	return _previous_velocity


## Called by InteractionResolver when this entity takes damage.
func take_damage(amount: int) -> void:
	if is_broken:
		return
	
	current_hp = maxi(0, current_hp - amount)
	
	# Play damage flash
	if anim_player:
		anim_player.play("damage_flash")
	
	# Update visual state based on remaining HP
	_update_damage_visual()
	
	print("TestDummy took %d damage, HP: %d/%d" % [amount, current_hp, max_hp])
	
	if current_hp <= 0:
		_break()


## Restore the dummy to full health and idle state.
func _respawn() -> void:
	current_hp = max_hp
	is_broken = false
	_respawn_timer = 0.0
	
	# Re-enable collision on all surfaces
	for surface_name in _surfaces:
		var surface: InteractionSurface = _surfaces[surface_name]
		surface.set_deferred("monitorable", true)
		surface.set_deferred("monitoring", true)
	
	if sprite:
		sprite.animation = "idle"
		sprite.play()
	
	print("TestDummy respawned with %d HP" % max_hp)


## Transition to broken state.
func _break() -> void:
	is_broken = true
	
	# Disable collision on all surfaces
	for surface_name in _surfaces:
		var surface: InteractionSurface = _surfaces[surface_name]
		surface.set_deferred("monitorable", false)
		surface.set_deferred("monitoring", false)
	
	if sprite:
		sprite.animation = "broken"
		sprite.play()
	
	if respawn_delay > 0.0:
		_respawn_timer = respawn_delay
	
	print("TestDummy broken!")


## Update sprite to match current HP level.
func _update_damage_visual() -> void:
	if is_broken or not sprite:
		return
	
	# Map HP to animation:
	# max_hp = idle, max_hp-1 = damage1, max_hp-2 = damage2, max_hp-3+ = damage3
	var damage_taken: int = max_hp - current_hp
	
	if damage_taken <= 0:
		sprite.animation = "idle"
	elif damage_taken == 1:
		sprite.animation = "damage1"
	elif damage_taken == 2:
		sprite.animation = "damage2"
	else:
		sprite.animation = "damage3"
	
	sprite.play()


## Update the debug label with current state.
func _update_label() -> void:
	if not label:
		return
	
	if is_broken:
		if respawn_delay > 0.0:
			label.text = "BROKEN (%.1fs)" % _respawn_timer
		else:
			label.text = "BROKEN"
	else:
		label.text = "HP:%d/%d" % [
			current_hp, max_hp
		]


## Signal handler for non-InteractionSurface area collisions (tilemap, etc.)
func _on_area_2d_area_shape_entered(_area_rid: RID, _area: Area2D, _area_shape_index: int, _local_shape_index: int) -> void:
	pass


## Signal handler for body collisions (tilemap, etc.)
func _on_area_2d_body_shape_entered(_body_rid: RID, _body: Node2D, _body_shape_index: int, _local_shape_index: int) -> void:
	pass
